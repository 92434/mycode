#!/bin/sh

set -x
echo $0

case "$1" in
	start)
		if [ -e /proc/cpu/alignment ]; then
		   echo "3" > /proc/cpu/alignment
		fi
		echo "done."
		;;
	stop)
		;;
	restart)
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0
