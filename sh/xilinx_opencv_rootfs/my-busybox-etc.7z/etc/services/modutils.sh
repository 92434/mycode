#!/bin/sh

. /etc/default/rcS

set -x
echo $0

LOAD_MODULE=modprobe

process_file() {
	file=$1

	(cat $file; echo; ) |
	while read module args
	do
		case "$module" in
			\#*|"") continue ;;
		esac
		[ -n "$(echo $loaded_modules | grep " $module ")" ] && continue
		[ "$VERBOSE" != no ] && echo -n "$module "
		eval "$LOAD_MODULE $module $args >/dev/null 2>&1"
		loaded_modules="${loaded_modules}${module} "
	done
}

case "$1" in
	start)
		[ -f /proc/modules ] || exit 0
		[ -f /etc/modules ] || [ -d /etc/modules-load.d ] || exit 0
		[ -e /sbin/modprobe ] || LOAD_MODULE=insmod

		if [ ! -f /lib/modules/`uname -r`/modules.dep ]; then
			[ "$VERBOSE" != no ] && echo "Calculating module dependencies ..."
			depmod -Ae
		fi

		loaded_modules=" "


		[ "$VERBOSE" != no ] && echo -n "Loading modules: "
		[ -f /etc/modules ] && process_file /etc/modules

		[ -d /etc/modules-load.d ] || exit 0

		for f in /etc/modules-load.d/*.conf; do
			process_file $f
		done
		[ "$VERBOSE" != no ] && echo
		echo "done."
		;;
	stop)
		echo -n "stopping $DESC: $NAME... "
		start-stop-daemon -K -n $NAME
		echo "done."
		;;
	restart)
		echo "restarting $DESC: $NAME... "
		$0 stop
		$0 start
		echo "done."
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0
