#!/bin/sh
set -x
echo $0

case "$1" in
	start)
		if [ ! -e /dev/tty ]; then
		    mknod -m 0666 /dev/tty c 5 0
		fi

		if ( > /dev/tty0 ) 2>/dev/null; then
		    vtmaster=/dev/tty0
		elif ( > /dev/vc/0 ) 2>/dev/null; then
		    vtmaster=/dev/vc/0
		elif ( > /dev/console ) 2>/dev/null; then
		    vtmaster=/dev/console
		else
		    vtmaster=/dev/null
		fi
		echo > $vtmaster
		echo "Please wait: booting..." > $vtmaster
		;;
	stop)
		;;
	restart)
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0

