#!/bin/sh

set -x
echo $0

case "$1" in
	start)
		if [ -e /proc ] && ! [ -e /proc/mounts ]; then
		  mount -t proc proc /proc
		fi

		if [ -e /sys ] && grep -q sysfs /proc/filesystems && ! [ -e /sys/class ]; then
		  mount -t sysfs sysfs /sys
		fi

		if [ -e /sys/kernel/debug ] && grep -q debugfs /proc/filesystems; then
		  mount -t debugfs debugfs /sys/kernel/debug
		fi
		;;
	stop)
		;;
	restart)
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0

