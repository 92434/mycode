#!/bin/sh
### BEGIN INIT INFO
# Provides:             dmesg
# Required-Start:
# Required-Stop:
# Default-Start:        S
# Default-Stop:
### END INIT INFO

set -x
echo $0

case "$1" in
	start)
		if [ -f /var/log/dmesg ]; then
			if [ -f /usr/sbin/logrotate ]; then
				logrotate -f /etc/logrotate-dmesg.conf
			else
				mv -f /var/log/dmesg /var/log/dmesg.old
			fi
		fi
		dmesg -s 131072 > /var/log/dmesg
		echo "done."
		;;
	stop)
		;;
	restart)
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0
