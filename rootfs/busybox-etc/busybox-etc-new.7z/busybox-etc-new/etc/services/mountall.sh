#!/bin/sh

set -x
echo $0

. /etc/default/rcS

case "$1" in
	start)
#
# Mount local filesystems in /etc/fstab. For some reason, people
# might want to mount "proc" several times, and mount -v complains
# about this. So we mount "proc" filesystems without -v.
#
		test "$VERBOSE" != no && echo "Mounting local filesystems..."
		mount -at nonfs,nosmbfs,noncpfs 2>/dev/null

#
# We might have mounted something over /dev, see if /dev/initctl is there.
#
		if test ! -p /dev/initctl
		then
			rm -f /dev/initctl
			mknod -m 600 /dev/initctl p
		fi
		#kill -USR1 1

#
# Execute swapon command again, in case we want to swap to
# a file on a now mounted filesystem.
#
		swapon -a 2> /dev/null
		echo "done."
		;;
	stop)
		;;
	restart)
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
		;;
esac

exit 0

