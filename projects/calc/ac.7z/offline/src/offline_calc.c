
// For clarity,error checking has been omitted.

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>   
#include <sys/types.h>   
#include <sys/wait.h>  
#include <syslog.h>  
#include <pthread.h>
#include "common_fun.h"
//#include "csa.h"
#include "csa_dma.h"
#include "offline_calc.h"

static int work_mode=0;// 1:create chain header 2:calc chain tail 3:sort rainbow table
static FILE  *record_file_fd=NULL;
static FILE  *table_fd=NULL;
static long chain_table_pos=0;
static long chain_header_pos=0;
static int calc_table_pos=0;
static long calc_chain_pos=0;
static long sort_chain_pos=0;


#define sw16(x) \
   ((short)(\
      (((short)(x)&(short)0x00ffU)<< 8) |\
      (((short)(x)&(short)0xff00U)>> 8)))
#define Swap64(ll) (((ll) >> 56) |(((ll) & 0x00ff000000000000) >> 40)  |(((ll) & 0x0000ff0000000000) >> 24)|(((ll) & 0x000000ff00000000) >> 8)|(((ll) & 0x00000000ff000000) << 8)|(((ll) & 0x0000000000ff0000) << 24)|(((ll) & 0x000000000000ff00) << 40)|(((ll) << 56))) 
#define Swap48(ll) (((ll) >> 56) |(((ll) & 0x00ff000000000000) >> 40)  |(((ll) & 0x0000ff0000000000) >> 24)|(((ll) & 0x000000ff00000000) >> 8)|(((ll) & 0x00000000ff000000) << 8)|(((ll) & 0x0000000000ff0000) << 24)|(((ll) & 0x000000000000ff00) << 40)|(((ll) << 56))) 
#define IDX_ITEM_LEN 8
#define IDX_HEADER_BITS 24//no more than 32
typedef struct{
	unsigned long long idx_header:IDX_HEADER_BITS;
	unsigned long long file_pos:40;
}_idx_item_stru;
typedef union{
	unsigned long long ll_value;
	_idx_item_stru _idx_value;
}_union_idx;
static _idx_item_stru latest_idx;
static int idx_item_cnt=0;
//static _idx_item_stru *index_array=NULL;
//static unsigned long long table_file_size=0;
static unsigned char * index_buf=NULL;
//static unsigned char *table_buf=NULL;


unsigned long long StrToLong_6B(unsigned char *buf){
	unsigned long long a=0;
	a=((unsigned long long)buf[0]<<40)|
		((unsigned long long)buf[1]<<32)|
		((unsigned long long)buf[2]<<24)|
		((unsigned long long)buf[3]<<16)|
		((unsigned long long)buf[4]<<8)|
		buf[5];
	return a;
}

int restore_create_chain_pos(void){
	char string[256]={0};
	record_file_fd=fopen("chain.cfg","w+");//д��ʱ������ļ����ڣ��ᱻ��գ���ͷ��ʼд
	if(record_file_fd==NULL){
		TRACE("chain.cfg open fail[B],pls check(%s)\n",strerror(errno));
		return -1;
	}
	snprintf(string,128,"chain_table_pos:%ld\r\n",chain_table_pos);
	fputs(string,record_file_fd);
	
	memset(string,0,128);
	snprintf(string,128,"create_chain_pos:%ld\r\n",chain_header_pos);
	fputs(string,record_file_fd);

	memset(string,0,128);
	snprintf(string,128,"calc_table_pos:%d\r\n",calc_table_pos);
	fputs(string,record_file_fd);
	
	memset(string,0,128);
	snprintf(string,128,"calc_chain_pos:%ld\r\n",calc_chain_pos);
	fputs(string,record_file_fd);

	memset(string,0,128);
	snprintf(string,128,"sort_chain_pos:%ld\r\n",sort_chain_pos);
	fputs(string,record_file_fd);
	
	if(record_file_fd){
		fclose(record_file_fd);
		record_file_fd=NULL;
	}
	return 0;
}

void signal_handler(int signo)   
{   
    signal(signo, signal_handler);  
    switch(signo)   
    {   
		case SIGHUP:
		case SIGINT:  
		case SIGTERM:
		case SIGQUIT:
		{
			TRACE("exit msg\n");
			if(table_fd){
				fclose(table_fd);
				table_fd=NULL;
			}
			restore_create_chain_pos();
			destroy_csa_dma();
            exit(0);   
    	}
         break;   
        case SIGALRM:   
             {   
	             syslog(LOG_NOTICE, "Process recieve SIGALRM");   
	             break;   
             }   
		case SIGSEGV:{
			int loopflag = 1;
			while(loopflag){        
			    sleep(1);
				TRACE("\n=============================================\n");
			}
			break;
		
		}/**/
		
        case SIGCHLD:   
             {   
			int *pidstat=NULL;   
			pid_t pid;   
			pid = waitpid(0, pidstat, WNOHANG);   
			if (pid>0)   
				syslog(LOG_WARNING, "child %d terminated\n", pid);   
			syslog(LOG_NOTICE, "exit handle child process\n");   
			break;   
		}   
        default:   
             syslog(LOG_WARNING, "%d signal unregister\n", signo);   
             break;   
    }   
}


unsigned int getHeader(unsigned char *buf){
	unsigned int a=0;
	int i;
	for(i=0;i<IDX_HEADER_BITS/8;i++){
		a+=(unsigned int)buf[i]<<(IDX_HEADER_BITS-8*(i+1));
	}
	return a;
}

/*
table_file:	table file name
idx_item_len:	length of each index item,such as front 4B
*/

int create_dic_index(char* table_file){
	#define READ_DIC_BUFSIZE (CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*102400
	unsigned char buf[READ_DIC_BUFSIZE]={0};
	int n,i;
	int tmp_header=0;
	//int seg_doidx_finished=0;
	int chain_item_count=0;
	//_union_idx tmp_idx_value;
	unsigned int idx_header=0;
	unsigned long long tmp_idx_pos=0;//,tmp_header_BE=0;
	_idx_item_stru idx_struct;
	FILE  *idx_file_fd=NULL;
	idx_file_fd=fopen("index","ab");//д��ʱ������ļ����ڣ��ᱻ��գ���ͷ��ʼд
	if(idx_file_fd==NULL){
		TRACE("index file open fail,pls check(%s)\n",strerror(errno));
		return -1;
	}
	/*n=fseek(idx_file_fd,-1L*sizeof(_idx_item_stru),SEEK_END);
	if(n<0){
		memset(&latest_idx,0,sizeof(_idx_item_stru));
		tmp_idx_pos=0;
	}
	else{
		n=fread((char*)&latest_idx,1,sizeof(_idx_item_stru),idx_file_fd);
		if(n<=0){
			TRACE("read index file err(%s)\n",strerror(errno));
			return -2;
		}
		tmp_idx_pos=latest_idx.file_pos;
	}
	*/
	latest_idx.idx_header=0xFFFFFF;
	if(table_fd==NULL)
		table_fd=fopen(table_file,"r");
	if(table_fd==NULL){
		TRACE("open table file:%s fail,err:%s\n",table_file,strerror(errno));
		return -1;
	}
	
	n=fseek(table_fd ,(tmp_idx_pos==0)?0:(tmp_idx_pos+(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)), SEEK_SET);
	if(n!=0){
		TRACE("table file seek fail:%s \n",strerror(errno));
		goto create_idx_end;
	}
	//tmp_header_BE=0;
create_idx_start:
	//chain_item_count=0;
	memset(buf,0,READ_DIC_BUFSIZE);
	//find the first empty chain item(without chain_tail)
	n=fread(buf,1,READ_DIC_BUFSIZE,table_fd);
	if(n<(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)||n%(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)!=0){
		TRACE("table file read fail or reach the file end,err:%s,n:%d \n",strerror(errno),n);
		goto create_idx_end;
	}
	chain_item_count=n/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	//tmp_header_BE=htonl(latest_idx.idx_header);
	for(i=0;i<chain_item_count;i++){
		idx_header=getHeader(buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		if(latest_idx.idx_header==idx_header)
			continue;
		else{
			latest_idx.idx_header=idx_header;
			
			tmp_header=idx_header;
			idx_struct.idx_header=((tmp_header&0xFF)<<16)|(tmp_header&0xFF00)|((tmp_header&0xFF0000)>>16);
			idx_struct.file_pos=tmp_idx_pos+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
			fwrite((unsigned char*)&idx_struct,1,sizeof(_idx_item_stru),idx_file_fd);
			//TRACE("tmp_idx_value:%llx,tmp_header:%llx,idx_header:%llx,pos:%llx\n",tmp_idx_value.ll_value,tmp_header,idx_struct.idx_header,idx_struct.file_pos);
			//dump_packet_line("", (unsigned char*)&idx_struct, 8);
		}
	}
	tmp_idx_pos+=n;
	goto create_idx_start;
create_idx_end:	
	if(table_fd>0){
		fclose(table_fd);
		table_fd=NULL;
	}
	if(idx_file_fd>0){
		fclose(idx_file_fd);
		idx_file_fd=NULL;
	}
	TRACE("create index end time:%d,idx_pos:%lld\n",(int)time((time_t *) 0),tmp_idx_pos);
	return 0;
}

_idx_item_stru * load_dic_index(char* index_file){
	unsigned long long file_size=0,n,i;
	int j;
	unsigned char temp=0,*buf=NULL;
	FILE  *idx_file_fd=NULL;
	idx_file_fd=fopen(index_file,"rb+");
	if(idx_file_fd==NULL){
		TRACE("index file open fail,pls check(%s)\n",strerror(errno));
		return NULL;
	}
	n=fseek(idx_file_fd,0,SEEK_END);
	if(n<0){
		goto load_dic_err; 
	}
	else{
		file_size = ftell(idx_file_fd);
		TRACE("dic_index file(%s) size:%lld\n",index_file,file_size);
	}
	index_buf=(unsigned char *)malloc(file_size);
	if(index_buf==NULL){
		TRACE("MALLOC memory(%lldB) for index file err:%s\n",file_size,strerror(errno));
		goto load_dic_err; 
	}
	else
		TRACE("MALLOC memory(%lldB) for index file ok\n",file_size);
	
	fseek(idx_file_fd,0,SEEK_SET);
	n=fread(index_buf,1,file_size,idx_file_fd);
	if(n!=file_size){
		TRACE("read index file err:%s(read %lld B)",strerror(errno),file_size);
		goto load_dic_err; 
	}
	else
		TRACE("read index file finished.");
	idx_item_cnt=file_size/IDX_ITEM_LEN;
	
	for(i=0;i<idx_item_cnt;i++){
		buf=index_buf+i*IDX_ITEM_LEN;
		for(j=0;j<(IDX_HEADER_BITS/8)/2;j++){
			temp=buf[(IDX_HEADER_BITS/8)-j-1];
			buf[(IDX_HEADER_BITS/8)-j-1]=buf[j];
			buf[j]=temp;
		}
	}
		
	return (_idx_item_stru *)index_buf;
load_dic_err:
	if(index_buf){
		free(index_buf);
		index_buf=NULL;
	}
	if(idx_file_fd>0){
		fclose(idx_file_fd);
		idx_file_fd=NULL;
	}
	return NULL;
}

/*create chain header 
chain_header_length:
item_account:the total account of record in each table
table_idx:create chain header for current table
table_file:the rainbow table bin file path
*/
int create_chain_header_func(char* table_file){
	#define CREATE_UNIT_NO 1024
	#define WRITE_FILE_BUFSIZE (CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*CREATE_UNIT_NO
	int i,ii,n;
	long j,record_temp_counter=0;
	int start_table=chain_table_pos;
	unsigned char buf[WRITE_FILE_BUFSIZE]={0};
	unsigned char rand_head[5]={0};//[TABLE_COUNT][]={{'0','1','2'},{'3','4','5'},{'6','7','8'},{'9','A','B'},{'C','D','E','F'}};
	int fd = open("/dev/urandom", O_RDONLY);  //��urandom�ķ������������
	
	//open(table_file,O_RDWR|O_CREAT|O_APPEND,S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP);
	
	//create tables
	for(i=start_table;i<TABLE_COUNT;i++){
		long loop_pos=0;
		int item_each_loop_wide=0,loop_idx=0;
		int rand_loop_cnt=0;
		long start_header_intable=chain_header_pos;
		int buf_pos=0;
		if(table_fd==NULL){
			char file_name[32]={0};
			snprintf(file_name,32,"%s_%d",table_file,i);
			table_fd=fopen(file_name,"ab+");
			if(table_fd==NULL){
				TRACE("open table file:%s fail\n",file_name);
				return -1;
			}
			else
				TRACE("create %s\n",file_name);
		}
		switch(i){
			case 0:
				rand_loop_cnt=3;rand_head[0]=0x00,rand_head[1]=0x10,rand_head[2]=0x20;
				break;
			case 1:
				rand_loop_cnt=3;rand_head[0]=0x30,rand_head[1]=0x40,rand_head[2]=0x50;
				break;
			case 2:
				rand_loop_cnt=3;rand_head[0]=0x60,rand_head[1]=0x70,rand_head[2]=0x80;
				break;
			case 3:
				rand_loop_cnt=3;rand_head[0]=0x90,rand_head[1]=0xA0,rand_head[2]=0xB0;
				break;
			case 4:
				rand_loop_cnt=4;rand_head[0]=0xC0,rand_head[1]=0xD0,rand_head[2]=0xE0,rand_head[3]=0xF0;
				break;
		}
		if(ITEM_COUNT_INTABLE<rand_loop_cnt)
			item_each_loop_wide=rand_loop_cnt;
		else
			item_each_loop_wide=ITEM_COUNT_INTABLE/rand_loop_cnt;//ÿ�ε�С���䳤�ȣ�
		loop_pos=chain_header_pos%item_each_loop_wide;
		loop_idx=chain_header_pos/item_each_loop_wide;
		record_temp_counter=0;
		memset(buf,0,WRITE_FILE_BUFSIZE);
		TRACE("table idx:%d,the %ld chain,loop_wide:%d,loop_pos:%ld,loop_idx:%d,loop_header_char:%0x\n",
			i,start_header_intable,item_each_loop_wide,loop_pos,loop_idx,rand_head[loop_idx]);
		for(j=start_header_intable;j<ITEM_COUNT_INTABLE;j++){
			buf_pos=record_temp_counter*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
			while((n=read(fd, buf+buf_pos, CHAIN_HEADER_LENGTH))==CHAIN_HEADER_LENGTH){
				break;
			}
			
			*(buf+buf_pos)&=0x0F;
			*(buf+buf_pos)|=rand_head[loop_idx];
			loop_pos++;
			if(loop_pos>=item_each_loop_wide){
				loop_pos=0;
				loop_idx++;
			}
			chain_header_pos++;
			record_temp_counter++;
			if(record_temp_counter>=CREATE_UNIT_NO){
				n=fwrite(buf,WRITE_FILE_BUFSIZE,1,table_fd);
				if(n<=0)
					TRACE("write table file error,a:%s\n",strerror(errno));
				record_temp_counter=0;
				memset(buf,0,WRITE_FILE_BUFSIZE);
			}
			#if 0
			{
				unsigned char ppp[10]={0};
				memcpy(ppp,buf+buf_pos, CHAIN_HEADER_LENGTH);
				//TRACE("chain_header_pos:%ld,ppp:%s\n",chain_header_pos,ppp);
				TRACE("%0x ",rand_head[loop_idx]);
				dump_packet_line("ppp",ppp,9);
			}
			#endif
		}
		
		if(record_temp_counter>0){
			n=fwrite(buf,(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*record_temp_counter,1,table_fd);
			if(n<=0){
				TRACE("write table file error,b:%s\n",strerror(errno));
			}
		}

		//verify tables
		unsigned char zero[6]={0};
		int verify_result=0,verify_times=0;
		n=fseek(table_fd ,0, SEEK_SET);
		if(n!=0){
			TRACE("lseek the start of the table fail:%s\n",strerror(errno));
			goto create_end;
		}
		while(1){
			n=fread(buf,1,WRITE_FILE_BUFSIZE,table_fd);
			if(n<=0){
				TRACE("Verify break or reach the file end, exit:%s\n",strerror(errno));
				break;
			}
			record_temp_counter=n/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
			for(ii=0;ii<record_temp_counter;ii++){
				if(memcmp(buf+ii*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),zero,CHAIN_HEADER_LENGTH)==0||
					memcmp(buf+ii*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH,zero,CHAIN_TAIL_LENGTH)!=0){
					//fpos_t filepos;
					verify_result=-1;
					//fgetpos(table_fd, &filepos);
					//TRACE("table file broken at :");
					//showfpos(&filepos);
					//TRACE("\n");
					dump_packet((char*)"dump file",buf,WRITE_FILE_BUFSIZE);
					break;
				}
				verify_times++;
			}
		}
		if(verify_result==0){
			TRACE("table_%ld verify ok,verify_times:%d\n",chain_table_pos,verify_times);
		}
		//end
	create_end:
		if(table_fd){
			fclose(table_fd);
			table_fd=NULL;
		}
		
		chain_header_pos=0;
		chain_table_pos++;
		break;
	}
	if(fd){
		close(fd);
	}
	return 0;
}

#define CALC_QUEUE_LEN ITEM_CNT_PER_TIME
#define READ_FILE_BUFSIZE (CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*CALC_QUEUE_LEN

int calc_chain_tail_func(char* table_file){
	unsigned char buf[READ_FILE_BUFSIZE]={0};
	int readByte=0,table_idx=0,ret=0;
	long chain_item_count=0,n;
	int start_table=calc_table_pos;
	int write_Bytes=0;
	TRACE("start_table:%d\n",start_table);
	for(table_idx=start_table;table_idx<TABLE_COUNT;table_idx++){
		char table_name[32]={0};
		snprintf(table_name,32,"%s_%d",table_file,table_idx);
		if(table_fd==NULL)
			table_fd=fopen(table_name,"rb+");
		if(table_fd==NULL){
			TRACE("open table file:%s fail,err:%s\n",table_name,strerror(errno));
			return -1;
		}
		else
			TRACE("open table file %s ok\n",table_name);

		TRACE("calc begin time:%d\n",(int)time((time_t *) 0));
		start_seek:
		{
			n=fseek(table_fd , calc_chain_pos*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH) , SEEK_SET);
			if(n!=0){
				TRACE("table file seek fail:%s \n",strerror(errno));
				goto calc_end;
			}
		start_calc:
			chain_item_count=0;
			memset(buf,0,READ_FILE_BUFSIZE);
			//find the first empty chain item(without chain_tail)
			readByte=fread(buf,1,READ_FILE_BUFSIZE,table_fd);
			TRACE("read %d B\n",readByte);
			if(readByte<(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)||readByte%(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)!=0){
				TRACE("table file read fail or reach the file end,err:%s,n:%d \n",strerror(errno),readByte);
				//goto next_calc_loop;
				goto calc_end;
			}
			#if 0
			for(i=0;i<CALC_QUEUE_LEN;i++){
				if(i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)>=readByte)
					break;
				str=buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
				if(memcmp(str+CHAIN_HEADER_LENGTH,zero,CHAIN_TAIL_LENGTH)!=0){
					calc_chain_pos++;//repair the calc_chain_pos value
					TRACE("repair calc_chain_pos:%ld,offset:%d\n",calc_chain_pos,i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH));
					//dump_packet_line("zero", str,11);
					continue;
				}
				else{
					//chain_item[i].idx=chain_item_count+1;
					//memcpy(&chain_item[i].header,str,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
					chain_item_count++;
				}
			}
			#else
				chain_item_count=readByte/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
			#endif
			if(chain_item_count==0){
				TRACE("goto start_seek\n");
				goto start_seek;
			}
			else{
				n=fseek(table_fd , -chain_item_count*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH) , SEEK_CUR);//move back chain_item_count unit to reach the first empty pos in buf
				if(n!=0){
					TRACE("table file seek fail:%s \n",strerror(errno));
					goto calc_end;
				}
				TRACE("readByte:%d,chain_item_count:%ld\n",readByte,chain_item_count);
				
				//int strlength = chain_item_count,local_size=0;
				#if 0
				unsigned char cw[5]={0x10,0,0,0,0};
				memcpy(buf,cw,5);
				#endif
				/*status = clEnqueueWriteBuffer(commandQueue, inputBuffer, CL_TRUE, 0, READ_FILE_BUFSIZE, buf, 0, NULL, NULL);
				*/
				ret=csa_write_dma(buf, READ_FILE_BUFSIZE, &write_Bytes);
				if(ret!=0){
					TRACE("csa_write_dma err:%d\n",ret);
				}
				ret=csa_read_dma(buf, READ_FILE_BUFSIZE);
				if(ret!=0){
					TRACE("csa_read_dma err:%d\n",ret);
				}
				//write the calc result into table (include both chain header and tail)
				n=fwrite(buf,1,chain_item_count*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),table_fd);
				if(n!=chain_item_count*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)){
					TRACE("table file write fail:%s \n",strerror(errno));
					goto calc_end;
				}
				else{
					fflush(table_fd);
					calc_chain_pos+=chain_item_count;
					TRACE("table write the %ld chain ok,(%ld)finish rate:%f,calc_chain_pos:%ld,tm:%d\n",
						calc_chain_pos,chain_item_count,(float)calc_chain_pos*100/(ITEM_COUNT_INTABLE),calc_chain_pos,(int)time((time_t *) 0));
				}
				
				goto start_calc;
				//goto calc_end;
			}
		}
	
		if(table_fd>0){
			fclose(table_fd);
			table_fd=NULL;
		}
		calc_chain_pos=0;
		calc_table_pos++;
	}
calc_end:
	TRACE("calc end time:%d\n",(int)time((time_t *) 0));
	if(table_fd>0){
		fclose(table_fd);
		table_fd=NULL;
	}
	return ret;
}
//�ǵݹ��㷨
int binary( int *a, int key, int n )
{
	int left = 0, right = n - 1, mid = 0;
	mid = ( left + right ) / 2;
	while( left < right && a[mid] != key )
	{
		if( a[mid] < key )
			left = mid + 1;
		else if( a[mid] > key )
			right = mid - 1;
		mid = ( left + right ) / 2;
	}
	if( a[mid] == key )
		return mid;
	return -1;
}

void swapIfFirstIsGreater(unsigned char *a, unsigned char *b)
{
	unsigned long aa=((unsigned long)a[CHAIN_HEADER_LENGTH+0]<<40)|((unsigned long)a[CHAIN_HEADER_LENGTH+1]<<32)|((unsigned long)a[CHAIN_HEADER_LENGTH+2]<<24)|((unsigned long)a[CHAIN_HEADER_LENGTH+3]<<16)|((unsigned long)a[CHAIN_HEADER_LENGTH+4]<<8)|a[CHAIN_HEADER_LENGTH+5];
	unsigned long bb=((unsigned long)b[CHAIN_HEADER_LENGTH+0]<<40)|((unsigned long)b[CHAIN_HEADER_LENGTH+1]<<32)|((unsigned long)b[CHAIN_HEADER_LENGTH+2]<<24)|((unsigned long)b[CHAIN_HEADER_LENGTH+3]<<16)|((unsigned long)b[CHAIN_HEADER_LENGTH+4]<<8)|b[CHAIN_HEADER_LENGTH+5];
	if(aa > bb)
	{
		unsigned char temp[CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH]={0};
		memcpy(temp,a,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);	
		memcpy(a,b,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
		memcpy(b,temp,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	}
}

void bitonicSort_6B(
    unsigned char * input,
    const unsigned long length,
    const int sortIncreasing)
{
    const unsigned long halfLength = length/2;

    unsigned long i;
    for(i = 2; i <= length; i *= 2)
    {
        unsigned long j;
        for(j = i; j > 1; j /= 2)
        {
            int increasing = sortIncreasing;
            const unsigned long half_j = j/2;

            unsigned long k;
            for(k = 0; k < length; k += j)
            {
                const unsigned long k_plus_half_j = k + half_j;
                unsigned long l;

                if(i < length)
                {
                    if((k == i) || (((k % i) == 0) && (k != halfLength)))
                    {
                        increasing = !increasing;
                    }
                }

                for(l = k; l < k_plus_half_j; ++l)
                {
                    if(increasing)
                    {
                        swapIfFirstIsGreater(input+(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*l, 
					input+(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*(l + half_j));
                    }
                    else
                    {
                        swapIfFirstIsGreater(input+(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*(l + half_j), 
					input+(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*l);
                    }
                }
            }
        }
    }
}

int sort_seg_func(char* table_file){
	#define SORT_QUEUE_LEN 32768//268435456L//4294967296
	#define SORT_BUF_SIZE ((CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*SORT_QUEUE_LEN)
	unsigned char *buf=NULL;
	unsigned long readByte=0;
	unsigned long long file_size=0,n;
	int file_idx=0;
	buf = (unsigned char *)malloc(SORT_BUF_SIZE);
	if(buf==NULL){
		TRACE("malloc memory fail(%s)\n",strerror(errno));
		return -1;
	}
	
	if(table_fd==NULL)
		table_fd=fopen(table_file,"rb+");
	if(table_fd==NULL){
		TRACE("open table file:%s fail,err:%s\n",table_file,strerror(errno));
		goto sort_end;
	}
	else{
		n=fseek(table_fd,0,SEEK_END);
		if(n<0){
			goto sort_end;
		}
		else{
			file_size = ftell(table_fd);
			if(file_size<=0){
				TRACE("table file size err:%lld\n",file_size);
				goto sort_end;
			}
			TRACE("table filesize:%lld\n",file_size);
		}
	}

	
	TRACE("sort begin time:%d\n",(int)time((time_t *) 0));
	TRACE("sort begin sort_chain_pos:%ld\n",sort_chain_pos);
start_sort_seek:
	{
		n=fseek(table_fd , sort_chain_pos*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH) , SEEK_SET);
		if(n!=0){
			TRACE("table file seek fail:%s \n",strerror(errno));
			goto sort_end;
		}
	
		memset(buf,0,SORT_BUF_SIZE);
		//find the first empty chain item(without chain_tail)
		readByte=fread(buf,1,SORT_BUF_SIZE,table_fd);
		TRACE("read %ld B,tick:%d\n",readByte,(int)time((time_t *) 0));
		//dump_packet("ori data",buf,SORT_BUF_SIZE);
		if(readByte<(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)||readByte%(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)!=0){
			TRACE("table file read fail or reach the file end,err:%s,n:%ld \n",strerror(errno),readByte);
			goto sort_end;
		}
		long get_item_cnt=readByte/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
		if((get_item_cnt&(get_item_cnt-1))!=0){
			TRACE("table file read %ldB,get_item_cnt:%ld not Power of 2 \n",readByte,get_item_cnt);
			goto sort_end;
		}
		TRACE("get_item_cnt:%ld\n",get_item_cnt);
		bitonicSort_6B(buf,get_item_cnt,1);
		TRACE("bitonicSort_6B finished\n");
		/*for(int i=0;i<get_item_cnt;i++){
			dump_packet_line("", buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH));
		}*/
		sort_chain_pos+=get_item_cnt;
		{
			FILE  *seg_file_fd=NULL;
			char f_name[64]={0};
			//snprintf(f_name,64,"%ld_%d",sort_chain_pos,SORT_QUEUE_LEN);
			file_idx=sort_chain_pos/get_item_cnt-1;
			snprintf(f_name,64,"file%lld_no%02d.bin",file_size/SORT_BUF_SIZE,file_idx);
			seg_file_fd=fopen(f_name,"wb");//д��ʱ������ļ����ڣ��ᱻ��գ���ͷ��ʼд
			if(seg_file_fd==NULL){
				TRACE("f_name open fail,pls check(%s)\n",strerror(errno));
				goto sort_end;
			}
			fwrite(buf,1,get_item_cnt*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),seg_file_fd);
			fclose(seg_file_fd);
			TRACE("write file:%s,chain_table_pos:%ld,write_size:%ld,tick:%d\n",f_name,sort_chain_pos,
				get_item_cnt*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),(int)time((time_t *) 0));
			restore_create_chain_pos();
		}
		goto start_sort_seek;
	}

sort_end:
	if(buf){
		free(buf);
	}
	
	TRACE("sort end time:%d\n",(int)time((time_t *) 0));
	if(table_fd>0){
		fclose(table_fd);
		table_fd=NULL;
	}

	
	return 0;
}

int merge_sort(char *fileA, char *fileB, char * output_file){
	#define MERGE_MEM_LEN 16777216
	#define MERGE_BUF_SIZE (CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*MERGE_MEM_LEN

	FILE  *fd_A=NULL,*fd_B=NULL,*merge_file_fd=NULL;
	unsigned char *buf_A=NULL,*buf_B=NULL,*buf_Merge=NULL;

	int i,readByte=0;
	unsigned long long bufA_cur=0,bufA_fin=0,bufA_left=0;
	unsigned long long bufB_cur=0,bufB_fin=0,bufB_left=0;
	unsigned long long bufM_cur=0;//A_left:1 B_left:0
	unsigned long long Amax=0,Bmax=0,Max=0,TempA=0,TempB=0;
	int AB_flag=1;//1: A 0: B
	unsigned long long merge_file_size=0;
	
	if(fileA==NULL||fileB==NULL||output_file==NULL)
		return -1;
	fd_A=fopen(fileA,"rb+");
	if(fd_A==NULL){
		TRACE("open table fd_A:%s fail,err:%s\n",fileA,strerror(errno));
		goto merge_end;
	}
	fd_B=fopen(fileB,"rb+");
	if(fd_B==NULL){
		TRACE("open table fd_A:%s fail,err:%s\n",fileB,strerror(errno));
		goto merge_end;
	}
	//char f_name[64]="merge_file.bin";
	//snprintf(f_name,64,"%ld_%d",sort_chain_pos,SORT_QUEUE_LEN);
	
	merge_file_fd=fopen(output_file,"wb");//д��ʱ������ļ����ڣ��ᱻ��գ���ͷ��ʼд
	if(merge_file_fd==NULL){
		TRACE("f_name open fail,pls check(%s)\n",strerror(errno));
		goto merge_end;
	}
	
	buf_A = (unsigned char *)malloc(MERGE_BUF_SIZE);
	if(buf_A==NULL){
		TRACE("malloc buf_A memory fail(%s)\n",strerror(errno));
		goto merge_end;
	}
	buf_B = (unsigned char *)malloc(MERGE_BUF_SIZE);
	if(buf_B==NULL){
		TRACE("malloc buf_B memory fail(%s)\n",strerror(errno));
		goto merge_end;
	}
	buf_Merge = (unsigned char *)malloc(MERGE_BUF_SIZE*2);
	if(buf_Merge==NULL){
		TRACE("malloc buf_Merge memory fail(%s)\n",strerror(errno));
		goto merge_end;
	}
	TRACE("merge begin time:%d\n",(int)time((time_t *) 0));
	
merge_start:
	readByte=fread(buf_A+bufA_left,1,MERGE_BUF_SIZE-bufA_left,fd_A);
	bufA_fin=(bufA_left+readByte);///(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	bufA_cur=0;
	Amax=StrToLong_6B(buf_A+bufA_fin-CHAIN_TAIL_LENGTH);
	
	readByte=fread(buf_B+bufB_left,1,MERGE_BUF_SIZE-bufB_left,fd_B);
	bufB_fin=(bufB_left+readByte);///(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	bufB_cur=0;
	Bmax=StrToLong_6B(buf_B+bufB_fin-CHAIN_TAIL_LENGTH);
	
	memset(buf_Merge,0,MERGE_BUF_SIZE*2);
	bufM_cur=0;
	if(Amax<Bmax){
		Max=Amax;
		//AorB_left=0;
	}
	else{
		Max=Bmax;
		//AorB_left=1;
	}
	if(bufA_fin==0){
		if(bufB_fin!=0){
			fwrite(buf_B,1,bufB_fin,merge_file_fd);
			merge_file_size+=bufB_fin;
			printf("[B]write file :%llxB,total size:%llx\n",bufB_fin,merge_file_size);
		}
		goto merge_end;
	}
	if(bufB_fin==0){
		if(bufA_fin!=0){
			fwrite(buf_A,1,bufA_fin,merge_file_fd);
			merge_file_size+=bufA_fin;
			printf("[C]write file :%llxB,total size:%llx\n",bufA_fin,merge_file_size);
		}
		goto merge_end;
	}
//merge_loop:
	while(1){
		TempA=TempB=0;
		if(AB_flag){//A
			TempA=StrToLong_6B(buf_A+bufA_cur+CHAIN_HEADER_LENGTH);
			for(i=bufB_cur;i<bufB_fin;i+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH){
				TempB=StrToLong_6B(buf_B+i+CHAIN_HEADER_LENGTH);
				if(TempB>TempA)
					break;
			}
			if(i==bufB_cur){
				memcpy(buf_Merge+bufM_cur,buf_A+bufA_cur,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
				bufM_cur+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH;
				bufA_cur+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH;
				//memcpy(buf_Merge+bufM_cur,buf_B+bufB_cur,16);
				//bufM_cur+=16;
				//bufB_cur+=16;
			}
			else if(i>bufB_cur){
				memcpy(buf_Merge+bufM_cur,buf_B+bufB_cur,i-bufB_cur);
				bufM_cur+=(i-bufB_cur);
				bufB_cur+=(i-bufB_cur);
			}
			//printf("[AB_flag:%d,bufB_cur:%d,i:%d,%llx] ",AB_flag,bufB_cur,i,TempA);
		}
		else{//B
			TempB=StrToLong_6B(buf_B+bufB_cur+CHAIN_HEADER_LENGTH);
			for(i=bufA_cur;i<bufA_fin;i+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH){
				TempA=StrToLong_6B(buf_A+i+CHAIN_HEADER_LENGTH);
				if(TempA>TempB)
					break;
			}
			if(i==bufA_cur){
				memcpy(buf_Merge+bufM_cur,buf_B+bufB_cur,CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
				bufM_cur+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH;
				bufB_cur+=CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH;
				//memcpy(buf_Merge+bufM_cur,buf_A+bufA_cur,16);
				//bufM_cur+=16;
				//bufA_cur+=16;
			}
			else if(i>bufA_cur){
				memcpy(buf_Merge+bufM_cur,buf_A+bufA_cur,i-bufA_cur);
				bufM_cur+=(i-bufA_cur);
				bufA_cur+=(i-bufA_cur);
			}
			//printf("[AB_flag:%d,bufA_cur:%d,i:%d,%llx] ",AB_flag,bufA_cur,i,TempB);
		}
		AB_flag=!AB_flag;
		//printf("bufA_fin:%d,bufA_cur:%d,bufB_fin:%d,bufB_cur:%d\n",bufA_fin,bufA_cur,bufB_fin,bufB_cur);
		if(TempA>=Max||TempB>=Max){//one loop end
			fwrite(buf_Merge,1,bufM_cur,merge_file_fd);
			bufA_left=bufA_fin-bufA_cur;
			memmove(buf_A,buf_A+bufA_cur,bufA_left);
			bufB_left=bufB_fin-bufB_cur;
			memmove(buf_B,buf_B+bufB_cur,bufB_left);
			merge_file_size+=bufM_cur;
			printf("[A]write file :%llxB,total size:%llx,bufA_left:%llx,bufB_left:%llx\n",bufM_cur,merge_file_size,bufA_left,bufB_left);
			goto merge_start;
		}
	}
			
merge_end:
	TRACE("merge_end,bufA_fin:%lld,bufB_fin:%lld\n",bufA_fin,bufB_fin);
	if(fd_A>0){
		fclose(fd_A);
		fd_A=NULL;
	}
	if(fd_B>0){
		fclose(fd_B);
		fd_B=NULL;
	}
	if(merge_file_fd>0){
		fclose(merge_file_fd);
		merge_file_fd=NULL;
	}
	if(buf_A){
		free(buf_A);
	}
	if(buf_B){
		free(buf_B);
	}
	TRACE("merge end time:%d\n",(int)time((time_t *) 0));
	return 0;
}

void merge_seg_func(int file_num){
	int i,j;
	char fileA[64]={0},fileB[64]={0},fileO[64]={0};
	for(i=file_num/2;i>0;i=(i>>1)){
		for(j=0;j<i;j++){
			snprintf(fileA,64,"file%d_no%02d.bin",2*i,2*j);
			snprintf(fileB,64,"file%d_no%02d.bin",2*i,2*j+1);
			snprintf(fileO,64,"file%d_no%02d.bin",i,j);
			printf("step:%d,pass:%d,fileA:%s,fileB:%s,fileO:%s\n",i,j,fileA,fileB,fileO);
			merge_sort(fileA,fileB,fileO);
			if(0){//2*i!=file_num){
				if(remove(fileA)==0)
					TRACE("remove %s OK\n",fileA);
				else
					TRACE("remove %s fail\n",fileA);
				if(remove(fileB)==0)
					TRACE("remove %s OK\n",fileB);
				else
					TRACE("remove %s fail\n",fileB);
			}
		}
		//return;
	}
}

void check_sort_result(char* table_file){
	#define CHECK_BUFSIZE (CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)*102400
	unsigned char buf[CHECK_BUFSIZE]={0};
	int chain_item_count=0;
	unsigned long long TempA=0,TempB=0,i,n,file_pos=0;
	int ret=0;
	if(table_fd==NULL)
		table_fd=fopen(table_file,"r");
	if(table_fd==NULL){
		TRACE("open table file:%s fail,err:%s\n",table_file,strerror(errno));
		return;
	}
	
check_start:
	memset(buf,0,CHECK_BUFSIZE);
	n=fread(buf,1,CHECK_BUFSIZE,table_fd);
	if(n<(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)||n%(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)!=0){
		TRACE("table file read fail or reach the file end,err:%s,n:%lld \n",strerror(errno),n);
		goto check_end;
	}
	chain_item_count=n/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	for(i=0;i<chain_item_count-1;i++){
		TempA=StrToLong_6B(buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		TempB=StrToLong_6B(buf+(i+1)*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		if(TempA>=TempB){
			TRACE("sort err,file_pos:%lld,offset:%lld\n",file_pos,i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH));
			ret=-1;
			goto check_end;
		}
	}
	file_pos+=n;
	goto check_start;
	
check_end:	
	if(table_fd>0){
		fclose(table_fd);
		table_fd=NULL;
	}
	if(ret==0)
		TRACE("check sort result passed!\n");
	return;
}

void remove_repeate_item(char* table_file){
	#define READ_BUFSIZE 2952790016L
	unsigned char *buf=NULL,*buf_copy=NULL;
	FILE  *copyfile_fd=NULL;
	unsigned long long TempA=0,TempB=0,pos_begin=0,pos_end=0,i,j,n,max=0,file_pos=0,chain_item_count=0;
	if(table_fd==NULL)
		table_fd=fopen(table_file,"r");
	if(table_fd==NULL){
		TRACE("open table file:%s fail,err:%s\n",table_file,strerror(errno));
		return;
	}

	if(copyfile_fd==NULL)
		copyfile_fd=fopen("new_table","w+");
	if(copyfile_fd==NULL){
		TRACE("open copy file fail,err:%s\n",strerror(errno));
		goto remove_end;
	}

	buf=(unsigned char *)malloc(READ_BUFSIZE);
	if(buf==NULL){
		TRACE("malloc memory for buf fail,err:%s\n",strerror(errno));
		goto remove_end;
	}
	buf_copy=(unsigned char *)malloc(READ_BUFSIZE);
	if(buf_copy==NULL){
		TRACE("malloc memory for buf_copy fail,err:%s\n",strerror(errno));
		goto remove_end;
	}
remove_start:
	memset(buf,0,READ_BUFSIZE);
	memset(buf_copy,0,READ_BUFSIZE);
	n=fread(buf,1,READ_BUFSIZE,table_fd);
	if(n<(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)||n%(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)!=0){
		TRACE("table file read fail or reach the file end,err:%s,n:%lld \n",strerror(errno),n);
		goto remove_end;
	}
	
	TRACE("read table file %lld B,file_pos:%lld,pos_begin:%lld,max:%llx #",n,file_pos,pos_begin,max);
	file_pos+=n;
	
	chain_item_count=n/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	pos_begin=pos_end=0;
	j=0;
	for(i=0;i<chain_item_count-1;i++){
		TempB=StrToLong_6B(buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		if(TempB==max){
			pos_begin++;
		}
		else
			break;
	}
	
	for(;i<chain_item_count-1;i++){
		TempA=StrToLong_6B(buf+(i+1)*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		TempB=StrToLong_6B(buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
		
		if(TempA==TempB){
			pos_end=i+1;
			if(pos_end>pos_begin){
				memcpy(buf_copy+j*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),
					buf+pos_begin*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),
					(pos_end-pos_begin)*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH));
				j+=(pos_end-pos_begin);
			}
			pos_begin=pos_end+1;
		}
	}
	if(pos_begin<chain_item_count){//����buf����һ����
		memcpy(buf_copy+j*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),
			buf+pos_begin*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),
			(chain_item_count-pos_begin)*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH));
		j+=(chain_item_count-pos_begin);
	}
	n=fwrite(buf_copy,1,j*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),copyfile_fd);
	max=StrToLong_6B(buf+(chain_item_count-1)*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH);
	TRACE("write copy file %lld B!i:%lld,j:%lld,max:%llx\n",n,i,j,max);
	goto remove_start;
remove_end:
	if(buf)
		free(buf);
	if(buf_copy)
		free(buf_copy);
	if(table_fd>0){
		fclose(table_fd);
		table_fd=NULL;
	}

	if(copyfile_fd>0){
		fclose(copyfile_fd);
		copyfile_fd=NULL;
	}
	TRACE("remove_repeate_item finished!\n");
	return;
}


int init_config_file(char* table_file){
	char str[128]={0};
	record_file_fd=fopen(table_file,"rb");
	if(record_file_fd==NULL){
		TRACE("chain.cfg open fail,pls check\n");
		return -1;
	}

	while(!feof(record_file_fd) && fgets(str, 128, record_file_fd)){//
		char *buf=alltrim(str);
		if(memcmp(buf,"chain_table_pos:",16)==0)
		{
			chain_table_pos=strtoul((const char *)buf+16,0,10);
			if(chain_table_pos<0){
				TRACE("chain_table_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read chain_table_pos :%ld\n",chain_table_pos);
		}
		else if(memcmp(buf,"create_chain_pos:",17)==0)
		{
			chain_header_pos=strtoul((const char *)buf+17,0,10);
			if(chain_header_pos<0){
				TRACE("chain_header_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read chain_header_pos :%ld\n",chain_header_pos);
		}
		else if(memcmp(buf,"calc_table_pos:",15)==0)
		{
			calc_table_pos=strtoul((const char *)buf+15,0,10);
			if(calc_table_pos<0){
				TRACE("calc_table_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read calc_table_pos :%d\n",calc_table_pos);
		}
		else if(memcmp(buf,"calc_chain_pos:",15)==0)
		{
			calc_chain_pos=strtoul((const char *)buf+15,0,10);
			if(calc_chain_pos<0){
				TRACE("calc_chain_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read calc_chain_pos :%ld\n",calc_chain_pos);
		}
		else if(memcmp(buf,"sort_chain_pos:",15)==0)
		{
			sort_chain_pos=strtoul((const char *)buf+15,0,10);
			if(sort_chain_pos<0){
				TRACE("sort_chain_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read sort_chain_pos :%ld\n",sort_chain_pos);
		}
	}
	if(record_file_fd){
		fclose(record_file_fd);
		record_file_fd=NULL;
	}
	return 0;
}

void repair_cw(unsigned char *cw){
	int i;
	for(i=0;i<2;i++)
		cw[4*i+3]=(cw[4*i]+cw[4*i+1]+cw[4*i+2])&0xFF;
}


int init_signal(void){
	signal(SIGHUP, &signal_handler);   
	signal(SIGSEGV, &signal_handler);   
	signal(SIGQUIT, &signal_handler);   
	signal(SIGINT,  &signal_handler);   
	signal(SIGTERM, &signal_handler);   
	signal(SIGALRM, &signal_handler);   
	signal(SIGCHLD, &signal_handler);  
	signal(SIGPIPE, &signal_handler);
	return 0;
}
int main(int argc,char *  argv[])
{
	char str[128]={0};
	
	printf("Please choose work mode,input 1, 2 or 3:\n");// 1:create chain header 2:calc chain tail 3:sort rainbow table
	show_mode_select:
	printf("1.create chain header\n");
	printf("2.calc chain tail\n");
	printf("3.sort rainbow table\n");
	printf("4.merge sortable bin\n");
	printf("5.create table index\n");
	//printf("6.crack des with rainbow table\n");
	if(scanf("%d",&work_mode)<=0){
		TRACE("work_mode input err\n");
		return -1;
	}	
	
	init_signal();
	if(work_mode<=0||work_mode>=MAX_OP_MODE){
		printf("Please choose coreect work mode again:(%d)\n",work_mode);
		goto show_mode_select;
	}
	record_file_fd=fopen("chain.cfg","rb");
	if(record_file_fd==NULL){
		TRACE("chain.cfg open fail,pls check\n");
		return -1;
	}

	while(!feof(record_file_fd) && fgets(str, 128, record_file_fd)){//
		char *buf=alltrim(str);
		if(memcmp(buf,"chain_table_pos:",16)==0)
		{
			chain_table_pos=strtoul((const char *)buf+16,0,10);
			if(chain_table_pos<0){
				TRACE("chain_table_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read chain_table_pos :%ld\n",chain_table_pos);
		}
		else if(memcmp(buf,"create_chain_pos:",17)==0)
		{
			chain_header_pos=strtoul((const char *)buf+17,0,10);
			if(chain_header_pos<0){
				TRACE("chain_header_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read chain_header_pos :%ld\n",chain_header_pos);
		}
		else if(memcmp(buf,"calc_table_pos:",15)==0)
		{
			calc_table_pos=strtoul((const char *)buf+15,0,10);
			if(calc_table_pos<0){
				TRACE("calc_table_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read calc_table_pos :%d\n",calc_table_pos);
		}
		else if(memcmp(buf,"calc_chain_pos:",15)==0)
		{
			calc_chain_pos=strtoul((const char *)buf+15,0,10);
			if(calc_chain_pos<0){
				TRACE("calc_chain_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read calc_chain_pos :%ld\n",calc_chain_pos);
		}
		else if(memcmp(buf,"sort_chain_pos:",15)==0)
		{
			sort_chain_pos=strtoul((const char *)buf+15,0,10);
			if(sort_chain_pos<0){
				TRACE("sort_chain_pos err:%s\n",buf);
				return -1;
			}
			TRACE("read sort_chain_pos :%ld\n",sort_chain_pos);
		}
	}
	if(record_file_fd){
		fclose(record_file_fd);
		record_file_fd=NULL;
	}
	switch(work_mode){
		case CREATE_CHAIN_HEADER:{
			char file_name[64]="./table";
			create_chain_header_func(file_name);
		}
			break;
		case CALC_CHAIN_TAIL:{
			char file_name[64]="./table";
			if(argv[1]==NULL){
				TRACE("argv[1] shoule be the csa dma device name\n");
				return -1;
			}
			init_csa_dma(argv[1]);
			calc_chain_tail_func(file_name);
		}
			break;
		case SORT_RAINBOW_TABLE:{
			char file_name[64]="./table_0";
			sort_seg_func(file_name);
		}
			break;
		case MERGE_RAINBOW_TABLE:{
			//char file_name[64]="./table_0";
			//sort_seg_func(file_name);
		}
			break;
		case CREATE_TABLE_INDEX:{
			//char file_name[64]="./table_0";
			//sort_seg_func(file_name);
		}
			break;
		default:
			break;
	}
	restore_create_chain_pos();
	return 0;
}



