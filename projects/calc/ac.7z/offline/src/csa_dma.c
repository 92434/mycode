#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <pthread.h>
//#include "utils.h"
//#include "cypher_recv.h"
#include "csa_dma.h"
#include "common_fun.h"
static thread_arg_t csa_thread;
static int csa_stop = 0;
static unsigned char *cypher_buf=NULL;

void *csa_task(void *arg);

int destroy_csa_dma(void){
	csa_stop = 1;
	if(csa_thread.buffer)
		free(csa_thread.buffer);
	if(csa_thread.fd)
		close(csa_thread.fd);
	if(cypher_buf)
		free(cypher_buf);
	return 0;
}
int init_csa_dma(char* dma_dev){
	int ret = 0;
	
	if ((csa_thread.fd = open(dma_dev, O_RDWR))<0) {
		printf("err: can't open device(%s)!(%s)\n", dma_dev, strerror(errno));
		ret = -1;
		return ret;
	}

	csa_thread.buffer = (unsigned char *)malloc(CSA_BUFSIZE);
	if(csa_thread.buffer == 0) {
		printf("err: no memory for csa_thread.buffer(size:%d)!\n",CSA_BUFSIZE);
		ret = -1;
		return ret;
	}
	cypher_buf = (unsigned char *)malloc(ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
	if(cypher_buf == 0) {
		printf("err: no memory for cypher_buf!(size:%d)!\n",ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
		ret = -1;
		return ret;
	}
	
	return ret;
}

int csa_write_dma(unsigned char *table_buf, int buf_size, int *write_Bytes){
	thread_arg_t *targ = &csa_thread;
	int i;
	unsigned int block=0;
	int nwrite=0;
	int start_time=0,finish_time=MAX_QUERY_TIMES;
	memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
	for(i=0;i<ITEM_CNT_PER_TIME;i++){
		memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH,&block,4);
		memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+4,table_buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH),CHAIN_HEADER_LENGTH);
		memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+12,(unsigned char*)&finish_time,4);
		memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+16,(unsigned char*)&start_time,4);
	}
	nwrite = write(targ->fd, cypher_buf, i*DMA_WRITE_ITEM_LENGTH);
	if(write_Bytes) *write_Bytes=nwrite;
	if(nwrite < 0) {
		printf("write dma err(%s),nwrite:%d B\n", strerror(errno),nwrite);
		return -1;
	}
	else if(nwrite!=i*DMA_WRITE_ITEM_LENGTH){
		//reset
		printf("write dma err%s,nwrite:%d,should write %d items\n", strerror(errno),nwrite,i);
		return -2;
	}
	return 0;
}
int csa_read_dma(unsigned char *table_buf, int buf_size){
	thread_arg_t *targ = &csa_thread;
	int i,item_cnt=0,ret=0;
	int nread=0;
	memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
	item_cnt=buf_size/(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH);
	while(1){
		nread = read(targ->fd, cypher_buf, item_cnt*DMA_READ_ITEM_LENGTH);
		if(nread==item_cnt*DMA_READ_ITEM_LENGTH){
			for(i=0;i<item_cnt;i++){
				memcpy(table_buf+i*(CHAIN_HEADER_LENGTH+CHAIN_TAIL_LENGTH)+CHAIN_HEADER_LENGTH,
					cypher_buf+i*DMA_READ_ITEM_LENGTH+20,CHAIN_TAIL_LENGTH);
			}
			ret=0;
			break;
		}
		else if(nread < 0) {
			printf("read dma err(%s)\n", strerror(errno));
			ret=-1;
		}
		else if(nread!=item_cnt*DMA_READ_ITEM_LENGTH){
			//reset
			printf("read dma err%s,nread:%d items,should read %d items\n", strerror(errno),nread/DMA_READ_ITEM_LENGTH,item_cnt);
			ret=-2;
		}
		else if(csa_stop == 1) {
			ret=-3;
			break;
		}
	}
	return ret;
}


