#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include "utils.h"
#include "cypher_recv.h"
#include "csa_dma.h"
#include "common_fun.h"
#include "csa_crack.h"
static thread_arg_t csa_thread;
static int csa_stop = 0;
static int csa_force_stop = 0;
static unsigned char *cypher_buf=NULL;
extern QUEUE *cypher_queue;
void *csa_task(void *arg);

int destroy_csa_dma(void){
	csa_stop = 1;
	csa_force_stop = 1;
	if(csa_thread.buffer)
		free(csa_thread.buffer);
	if(csa_thread.fd)
		close(csa_thread.fd);
	if(cypher_buf)
		free(cypher_buf);
	return 0;
}
int init_csa_dma(char* dma_dev){
	int ret = 0;
	pthread_t tid;
	if ((csa_thread.fd = open(dma_dev, O_RDWR))<0) {
		printf("err: can't open device(%s)!(%s)\n", dma_dev, strerror(errno));
		ret = -1;
		return ret;
	}

	csa_thread.buffer = (unsigned char *)malloc(CSA_BUFSIZE);
	if(csa_thread.buffer == 0) {
		printf("err: no memory for csa_thread.buffer(size:%d)!\n",CSA_BUFSIZE);
		ret = -1;
		return ret;
	}
	cypher_buf = (unsigned char *)malloc(ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
	if(cypher_buf == 0) {
		printf("err: no memory for cypher_buf!(size:%d)!\n",ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
		ret = -1;
		return ret;
	}
	ret = pthread_create(&tid, NULL, csa_task, &csa_thread);
	if (ret != 0) {
		printf("can't create thread: %s\n", strerror(errno));
	}
	pthread_detach(tid);
	return ret;
}

//--memory(len=20):01 00 00 00 01 02 03 04 05 00 00 00 50 c3 00 00 00 00 00 00
//--memory(len=20):01 00 00 40 01 02 03 04 05 06 00 00 50 c3 00 00 00 00 00 00
void *csa_task(void *arg) {
	thread_arg_t *targ = (thread_arg_t *)arg;
	int up_triangle_item_cnt=0;
	T e;
	int i,cursor=0;
	int start_time,finish_time=0;
	unsigned int block=0;
	int nread=0,nwrite=0,read_total=0;
	//int is_first_matched=0;
	unsigned char first_header[CHAIN_HEADER_LENGTH]={0},zero[CHAIN_HEADER_LENGTH]={0},true_cw[8]={0};
	while(csa_stop == 0) {
		if(is_empty(*cypher_queue)!=1){
			out_queue(cypher_queue, &e);
			dump_packet_line("out_queue",e.cypher,7);
			cursor=0;
			read_total=0;
			up_triangle_item_cnt=0;
			//is_first_matched=0;
			block=e.id+(e.triangle<<30);
			memset(first_header,0,CHAIN_HEADER_LENGTH);
			memset(true_cw,0,8);
			//do up triangle process
			while(1){
				//write dma
				memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_WRITE_ITEM_LENGTH);
				for(i=0;(i<ITEM_CNT_PER_TIME)&&(cursor<MAX_QUERY_TIMES);i++,cursor++){
					start_time=cursor+1;
					finish_time=MAX_QUERY_TIMES;
					memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH,&block,4);
					memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+4,e.cypher,CHAIN_TAIL_LENGTH);
					memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+12,(unsigned char*)&finish_time,4);
					memcpy(cypher_buf+i*DMA_WRITE_ITEM_LENGTH+16,(unsigned char*)&start_time,4);
				}
				nwrite = write(targ->fd, cypher_buf, i*DMA_WRITE_ITEM_LENGTH);
				if(nwrite < 0) {
					printf("write dma err(%s),nwrite:%d B\n", strerror(errno),nwrite);
					break;
				}
				else if(nwrite!=i*DMA_WRITE_ITEM_LENGTH){
					//reset
					printf("write dma err%s,nwrite:%d,should write %d items\n", strerror(errno),nwrite,i);
					//csa_stop=1;
					break;
				}
				else if(csa_force_stop == 1) {
					break;
				}
				//printf("dma_csa write %d items,cursor:%d items\n",i,cursor);

				//read dma
				memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
				while(1){
					nread = read(targ->fd, cypher_buf, i*DMA_READ_ITEM_LENGTH);
					if(nread==i*DMA_READ_ITEM_LENGTH)
						break;
					else if(nread < 0) {
						printf("read dma err(%s)\n", strerror(errno));
					}
					else if(nread!=i*DMA_READ_ITEM_LENGTH){
						//reset
						printf("read dma err%s,nread:%d items,should read %d items\n", strerror(errno),nread/DMA_READ_ITEM_LENGTH,i);
						//csa_stop=1;
						
					}
					else if(csa_force_stop == 1) {
						break;
					}
				}
				if(read_total+i==MAX_QUERY_TIMES){
					memcpy(cypher_buf+i*DMA_READ_ITEM_LENGTH-8,e.cypher,7);
				}
				csa_fill_up_triangle(cypher_buf, read_total, i);
				read_total+=i;
				//printf("read dma %d items,read_total:%d items\n", nread/DMA_READ_ITEM_LENGTH,read_total);
				
				
				/*uint32_t *data=(uint32_t *)cypher_buf;
				for(i=0;i<nread/(4);i+=7){
					printf("block:<%01x>%10d in:0x%08x%08x times:%10d times_start:%10d out:0x%08x%08x\n",
							(data[i + 0] & 0xc0000000) >> 30,//block
							data[i + 0] & 0x3fffffff,//block
							data[i + 2],//in(high)
							data[i + 1],//in(low)
							data[i + 3],//times
							data[i + 4],//times_start
							data[i + 6],//out(high)
							data[i + 5]//out(low)
					);
					if(data[i + 3]==0)
						dump_packet("err data",(unsigned char*)&data[i + 0],28);
				}*/
				if(cursor>=MAX_QUERY_TIMES){
					csa_query_start(block);
					break;
				}
			}
			//query the tables
			while(csa_is_query_finished()==0){
				cs_sleepms(50);
			}
			TRACE("query table is done!");
			//do down triangle process
			nread=0;
			memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
			csa_get_down_triangle(cypher_buf,&up_triangle_item_cnt,first_header);
			//TRACE("[csa_get_down_triangle]up_triangle_item_cnt:%d\n",up_triangle_item_cnt);
			if(up_triangle_item_cnt>0){
				if(up_triangle_item_cnt%10!=0){
					int left=10-up_triangle_item_cnt%10;
					for(i=0;i<left;i++){
						unsigned int fake_block=0x0FFFFFFFL;
						start_time=1;
						finish_time=2;
						memcpy(cypher_buf+(up_triangle_item_cnt+i)*DMA_WRITE_ITEM_LENGTH,(unsigned char*)&fake_block,4);
						memcpy(cypher_buf+(up_triangle_item_cnt+i)*DMA_WRITE_ITEM_LENGTH+12,(unsigned char*)&finish_time,4);
						memcpy(cypher_buf+(up_triangle_item_cnt+i)*DMA_WRITE_ITEM_LENGTH+16,(unsigned char*)&start_time,4);
					}
					up_triangle_item_cnt+=left;
				}
				nwrite = write(targ->fd, cypher_buf, up_triangle_item_cnt*DMA_WRITE_ITEM_LENGTH);
				if(nwrite!=up_triangle_item_cnt*DMA_WRITE_ITEM_LENGTH){
					//reset
					printf("write dma err(%s),nwrite:%d,should write %d items\n", strerror(errno),nwrite,up_triangle_item_cnt);
					//csa_stop=1;
					break;
				}
				else
					TRACE("write dma for down triangle ok,%d items,nwrite:%dB\n",up_triangle_item_cnt,nwrite);
				
				memset(cypher_buf,0,ITEM_CNT_PER_TIME*DMA_READ_ITEM_LENGTH);
				while(1){
					nread = read(targ->fd, cypher_buf, up_triangle_item_cnt*DMA_READ_ITEM_LENGTH);
					TRACE("nread:%d,should be %dB\n",nread,up_triangle_item_cnt*DMA_READ_ITEM_LENGTH);
					if(nread==up_triangle_item_cnt*DMA_READ_ITEM_LENGTH)
						break;
					else if(nread!=up_triangle_item_cnt*DMA_READ_ITEM_LENGTH){
						//reset
						printf("read dma err%s,nread:%d items,should read %d items\n", strerror(errno),nread/DMA_READ_ITEM_LENGTH,i);
						//csa_stop=1;
					}
					else if(csa_force_stop == 1) {
						break;
					}
				}
			}
			else
			{
				if(memcmp(first_header,zero,CHAIN_HEADER_LENGTH)==0)
					dump_packet_line("[WARNING]can not find matched tail in table for plain text:",e.cypher,7);
			}
			uint32_t *data=(uint32_t *)cypher_buf;
			for(i=0;i<nread/(4);i+=7){
				printf("block:<%01x>%8x in:0x%08x%08x times:%10d times_start:%10d out:0x%08x%08x\n",
						(data[i + 0] & 0xc0000000) >> 30,//block
						data[i + 0] & 0x3fffffff,//block
						data[i + 2],//in(high)
						data[i + 1],//in(low)
						data[i + 3],//times
						data[i + 4],//times_start
						data[i + 6],//out(high)
						data[i + 5]//out(low)
				);
				if(data[i + 3]==0)
					dump_packet("err data",(unsigned char*)&data[i + 0],28);
			}/**/
			if(memcmp(first_header,zero,CHAIN_HEADER_LENGTH)!=0){
				dump_packet_line("first_header",first_header,CHAIN_HEADER_LENGTH);
				finish_time=start_time=0;
				memcpy(cypher_buf+up_triangle_item_cnt*DMA_READ_ITEM_LENGTH+12,(unsigned char*)&finish_time,4);
				memcpy(cypher_buf+up_triangle_item_cnt*DMA_READ_ITEM_LENGTH+16,(unsigned char*)&start_time,4);
				memcpy(cypher_buf+up_triangle_item_cnt*DMA_READ_ITEM_LENGTH+20,first_header,CHAIN_HEADER_LENGTH);
				up_triangle_item_cnt++;
			}
			TRACE("csa_check_valid_cw\n");
			if(csa_check_valid_cw(cypher_buf, up_triangle_item_cnt, e.cypher, true_cw)){
				dump_packet_line("find true cw",true_cw,8);
			}
			else
				printf("can not find cw,finished\n");
			TRACE("take %d seconds\n",(int)time((time_t *) 0)-e.tm);
			csa_reset_query();
		}
		else{
			cs_sleepms(100);
		}
	}
	return 0;
}

