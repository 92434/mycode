#ifndef _CYPHER_RECV_H_
#define _CYPHER_RECV_H_
#include "queue.h" 

#define CYPHER_DATA_LEN 19
#define GET_CYPHER_PORT 4500
int init_cypher_receiver(void);
int destroy_cypher_receiver(void);
#endif