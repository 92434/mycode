#ifndef _QUEUE_
#define _QUEUE_

#ifdef __cplusplus
extern "C"{
#endif

#define QUEUE_MAXSIZE 20000

typedef struct{//nearly 40B
	unsigned int id:30;
	unsigned int triangle:2;
	unsigned char program_info[10];
	unsigned char cypher[7];
	unsigned char reserved;
	int tm;
}_behavior_str,T;

typedef struct tag  
{  
    int front, rear, MaxSize, count; //��ʵMaxSize������ȫ���Բ�Ҫ  
    T elements[QUEUE_MAXSIZE];  
} QUEUE;  

void creat_queue( QUEUE *queue );
int is_empty( QUEUE queue);
int is_full( QUEUE queue );
void in_queue( QUEUE *queue, T *value );
int out_queue( QUEUE *queue, T *value );
void print_queue( QUEUE queue );

#ifdef __cplusplus
}
#endif

#endif

