#ifndef _CSA_DMA_H_
#define _CSA_DMA_H_
#define CSA_BUFSIZE (4 * 3 * 4 * 10)
typedef struct {
	int fd;
	unsigned char *buffer;
} thread_arg_t;

#define ITEM_COUNT_INTABLE 5629499534L// // 2^48/50000/5
#define TABLE_COUNT		5
#define CHAIN_HEADER_LENGTH 5
#define CHAIN_TAIL_LENGTH 6
#define PROCESS_PROGRAM_NUM	5
#define MAX_QUERY_TIMES 50000
#define ITEM_CNT_PER_TIME 1500
#define DMA_WRITE_ITEM_LENGTH (5*4)
#define DMA_READ_ITEM_LENGTH (7*4)
#define DMA_ITEM_MAX_CNT 1600
int init_csa_dma(char* dma_dev);
int destroy_csa_dma(void);
#endif

