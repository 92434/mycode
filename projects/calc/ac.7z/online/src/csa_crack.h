#ifndef _CSA_CRACK_H_
#define _CSA_CRACK_H_

typedef struct{
	unsigned char header[CHAIN_HEADER_LENGTH];
	unsigned char tail[CHAIN_TAIL_LENGTH];
	short match;
	unsigned char cw[8];
}calc_tail_stru;

int csa_query_start(unsigned int block);
int csa_query_stop(void);
int csa_fill_up_triangle(unsigned char *buf, int start_item, int item_num);
int csa_is_query_finished(void);
int csa_get_down_triangle(unsigned char *buf,int *result_num,unsigned char *matched_first_header);
int csa_check_valid_cw(unsigned char *buf, int item_num, unsigned char *plain, unsigned char *true_cw);
int init_csa_crack(void);
int csa_reset_query(void);
#endif
