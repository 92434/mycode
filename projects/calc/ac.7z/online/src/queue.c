/************************************************************************/  
/* author : thomas 
   E-mail: chenhua308@gmail.com                                         */  
/************************************************************************/  
//ѭ�����У�����ʵ�֣�  
#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include <time.h>
#include <errno.h>
#include <unistd.h> 
#include "queue.h"  


void creat_queue( QUEUE *queue )  
{  
    queue -> front = 0;  
    queue -> rear = 0;  
    queue -> count = 0;  
    queue -> MaxSize = QUEUE_MAXSIZE - 1;  
}  
int is_empty( QUEUE queue)  //��ʵ��ô�ָ�����ջ����̫��  
{  
    if ( queue.count == 0 )  
    {  
        return 1;  
    }  
    else  
    {  
        return 0;  
    }  
}  
int is_full( QUEUE queue )  
{  
    if ( queue.count == QUEUE_MAXSIZE )  
    {  
        return 1;  
    }  
    else  
    {  
        return 0;  
    }  
}  
void read_queue( QUEUE queue ) //just read the value  
{  
    if ( queue.count == 0 )  //������ǰ���is_empty���������ж�  
    {  
        printf("the queue is empty! no number is available! \n");  
    }  
    else  
    {  
       // printf("the first cli_idx is %d \n", queue.elements[queue.front].cli_index);  
    }  
}  
void in_queue( QUEUE *queue, T *value )  
{  
	if(value==NULL)
		return;
    if ( queue -> count == QUEUE_MAXSIZE )  //��������ǰ���is_full���������ж�  
    {  
        printf("sorry! the queue is full! no space is available!\n");  
    }  
    else  
    {  
		//if ( queue -> count != 0 ){
			//queue -> rear = (queue -> rear + 1) % QUEUE_MAXSIZE;  
		//}
		memcpy(&queue -> elements[queue -> rear] ,value,sizeof(T));
		queue -> count += 1;  
		//TRACE("[in]idx_in_queue:%d,user:%s\n",queue -> rear,queue -> elements[queue -> rear].user);
		queue -> rear = (queue -> rear + 1) % QUEUE_MAXSIZE;  
    }  
}  
int out_queue( QUEUE *queue, T *value )  
{  
	if(value==NULL)
		return -1;
    if ( queue -> count == 0 )  //��������ǰ���is_empty���������ж�  
    {  
        printf("sorry! the queue is empty! no number is available! \n");  
        //exit(EXIT_FAILURE);  
        return -1;
    }  
    else  
    {  
        queue -> count -= 1;  
		memcpy(value, &queue -> elements[queue -> front] ,sizeof(T));
		
		//TRACE("[out]idx_in_queue:%d,user:%s\n",queue -> front,queue -> elements[queue -> front].user);
		queue -> front = (queue -> front + 1) % QUEUE_MAXSIZE;  
        return 0;
    }  
}  
//print queue  
void print_queue( QUEUE queue )  
{  
    int i = 1/*, count*/;  
    if ( queue.count == 0 )  
    {  
        printf("the queue is empty! no number can be printed! \n");  
    }  
    else  
    {  
        //count = queue.count;  
        //printf("the number of queue is %d \n", queue.count);  
        for ( i=1; i <= queue.count; i++ )  
        {  
        	/*char user[9];
			memcpy(user,queue.elements[(queue.front + i - 1) % QUEUE_MAXSIZE].user,8);
            printf("the %04d cli_idx is %04d,user:%s, type:%c, content:%s,tm:%d \n", (queue.front + i - 1) % QUEUE_MAXSIZE, 
				queue.elements[(queue.front + i - 1) % QUEUE_MAXSIZE].cli_index,
				user,
				queue.elements[(queue.front + i - 1) % QUEUE_MAXSIZE].action_type,
				queue.elements[(queue.front + i - 1) % QUEUE_MAXSIZE].action_content,
				queue.elements[(queue.front + i - 1) % QUEUE_MAXSIZE].tm);  */
            //printf("the %d number is %d \n", i, queue.elements[queue.front + i - 1]);  
        }  
    }  
}  
//test functions  
#if 0
int main(int argc, char *argv[])  
{  
	int i;
	T e;
    QUEUE queue;  
    creat(&queue);  
    //out_queue(&queue);  
    //out_queue(&queue);  
    //print(queue);  
    //in_queue(&queue, 7);  
    printf("begin in_queue\n");
	for(i=0;i<QUEUE_MAXSIZE;i++){
		e.cli_index=i;
		snprintf(e.user,9,"usr%05d",i);
		e.tm=time((time_t *) 0);
		e.action_type='C';
		snprintf(e.action_content,24,"content%05d",i);
		e.port_index=0;
		in_queue(&queue, &e);
	}
	//sleep(1);
	printf("begin print\n");
    print(queue);  
	printf("begin out_queue\n");
	for(i=0;i<QUEUE_MAXSIZE;i++){
		char user[9];
		if(out_queue(&queue, &e)==0){
			memcpy(user,e.user,8);
	        printf("the %04d cli_idx is %04d,user:%s, type:%c, content:%s,tm:%d \n", i, 
				e.cli_index,
				user,
				e.action_type,
				e.action_content,
				e.tm); 
		}
	}
    return 0;
}  
#endif
