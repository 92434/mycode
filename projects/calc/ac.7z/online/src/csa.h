#ifndef _CSA_HEADER_
#define _CSA_HEADER_

int stream_cypher(int init, unsigned char *CK, unsigned char *sb, unsigned char *cb) ;
#endif