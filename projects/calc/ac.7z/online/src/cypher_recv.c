#include <netdb.h>
#include <pthread.h>
#include <signal.h>  
#include <sys/un.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <event2/bufferevent.h>
#include <event2/buffer.h>
#include <event2/listener.h>
#include <event2/util.h>
#include <event2/event.h>
#include "event2/buffer.h"
#include "cypher_recv.h"
#include "common_fun.h"


QUEUE *cypher_queue=NULL;
static pthread_t tid_cypher;
static struct event_base *cypher_base=NULL;


/*
receive data:11 22 program info(degree 2B+ freq 2B + sid 2B + vid 2B +aid 2B) cypher 7B =CYPHER_DATA_LEN
*/
static void cypher_data_process(struct bufferevent *bev, unsigned char *buf, size_t len,int *cli_idx){
	T e;
	static unsigned int new_id=0;
	while(len>=CYPHER_DATA_LEN){
		if(buf[0]==0x11&&buf[1]==0x22){
			e.id=new_id++;
			e.triangle=1;//up triangle op
			memcpy(e.program_info,buf+2,17);//both copy program info and cypher here 
			e.tm=(int)time((time_t *) 0);
			in_queue(cypher_queue, &e);
		}
		buf+=CYPHER_DATA_LEN;
		len-=CYPHER_DATA_LEN;
	}
}

static void cypher_readcb(struct bufferevent *bev, void *user_data)
{
	unsigned char buf[512];
	int n;//srv=*(int*)user_data;
	if(bev==NULL)
		return;
	
	while (n = bufferevent_read(bev, buf, 512), n > 0) {
		//TRACE("cypher_readcb from read Bytes: %d\n", n);
		if(n<50)
			dump_packet_line("cypher_readcb recv data", buf, n);
		cypher_data_process(bev,buf,n,user_data);
	}
}

static void cypher_eventcb(struct bufferevent *bev, short events, void *user_data)
{
	evutil_socket_t fd = bufferevent_getfd(bev);
	//printf("[monitor_eventcb] fd = %u", fd);
  
	if (events & BEV_EVENT_TIMEOUT) {
		TRACE("Timed out\n"); //if bufferevent_set_timeouts() called
	}
	else if (events & BEV_EVENT_EOF) {
		TRACE("Connection closed.(fd:%d)\n",fd);
	} else if (events & BEV_EVENT_ERROR) {
		TRACE("Got an error on the connection: %s\n",
		    strerror(errno));/*XXX win32*/
	}
	/* None of the other events can happen here, since we haven't enabled
	 * timeouts */
	
	
}

static void cypher_acceptcb(struct evconnlistener *listener, evutil_socket_t fd,
    struct sockaddr *sa, int socklen, void *user_data){
	struct event_base *base = user_data;
	struct bufferevent *bev;
	
	//TRACE("[monitor_acceptcb] \n");
	bev = bufferevent_socket_new(base, fd, BEV_OPT_CLOSE_ON_FREE);//|BEV_OPT_THREADSAFE
	if (!bev) {
		fprintf(stderr, "Error constructing bufferevent.err:%s\n!",evutil_socket_error_to_string(errno));
		//event_base_loopbreak(base);
		return;
	}
	TRACE("cypher_acceptcb %d ok\n",fd);
			
	bufferevent_setcb(bev, cypher_readcb, NULL, cypher_eventcb,NULL);
	//bufferevent_setwatermark(bev, EV_WRITE, 0, MAX_LINE);
	bufferevent_enable(bev, EV_READ|EV_PERSIST);//����bev���ĵ��¼�
}

static void* task_cypher_process(void *arg){
	struct sockaddr_in sin;
	struct evconnlistener *listener;
	cypher_base = event_base_new();
	if (!cypher_base) {
		fprintf(stderr, "Could not initialize cypher_base!\n");
		return 0;
	}
	TRACE("task_cypher_process\n");
	
	
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(GET_CYPHER_PORT);	
	
	listener = evconnlistener_new_bind(cypher_base, cypher_acceptcb, (void *)cypher_base,
	    LEV_OPT_REUSEABLE|LEV_OPT_CLOSE_ON_FREE, -1,
	    (struct sockaddr*)&sin,
	    sizeof(sin));
	if (!listener) {
		fprintf(stderr, "Could not create a listener!\n");
		return 0;
	}
	else
		TRACE("mgr_task_monitor listen port:%d success\n",GET_CYPHER_PORT);	
	
	/*struct event *ev;
	int ret=evutil_socketpair(AF_LOCAL, SOCK_STREAM, 0, socketpair_recycle_fd);
	if (ret == -1) {
        perror("socketpair() : ");
        return 0;
    }
	evutil_make_socket_nonblocking(socketpair_recycle_fd[0]);
	evutil_make_socket_nonblocking(socketpair_recycle_fd[1]);
	ev = event_new(monitor_base, socketpair_recycle_fd[0], EV_READ| EV_PERSIST, monitor_recyclecb,NULL);
    event_add(ev, NULL);*/

	event_base_dispatch(cypher_base);
	evconnlistener_free(listener);
	event_base_free(cypher_base);

	TRACE("task_cypher_process task done\n");
	
	return 0;
}

int destroy_cypher_receiver(void){
	if(cypher_queue)
		free(cypher_queue);
	event_base_loopbreak(cypher_base);
	if(tid_cypher) {pthread_kill(tid_cypher,SIGHUP);tid_cypher=0;}
	return 0;
}

int init_cypher_receiver(void){
	int args_tcp;
	cypher_queue=(QUEUE *)malloc(sizeof(QUEUE));
	if(cypher_queue==NULL){
		perror("malloc memory for queue err\n");
		return -1;
	}
	if(0 != CreateThread(task_cypher_process, (void *)&args_tcp,&tid_cypher,NULL)){
		TRACE("task_account_process create fail\n");
		return -2;
	}
	return 0;
}
