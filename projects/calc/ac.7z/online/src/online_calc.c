#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/poll.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>  
#include <sys/un.h>
#include <fcntl.h>
#include "common_fun.h"
#include "cypher_recv.h"
#include "csa_dma.h"
#include "csa_crack.h"
void signal_handler(int signo)   
{   
	//int i;
    signal(signo, signal_handler);  
    switch(signo)   
    {   
		case SIGHUP:
        case SIGINT:  
		case SIGTERM:
		case SIGQUIT:
			{
				TRACE("app exit and recycle resource!\n");
				destroy_cypher_receiver();
				destroy_csa_dma();
			}
			exit(0);
			break;
		case SIGSEGV:{//���ʷǷ��ڴ�
			int loopflag = 1;
			while(loopflag){        //������gdb���ֶ�����loopflag��ֵ����ѭ��
			    sleep(1);
				//������Դ�ӡһЩ����Ȥ�ı���
				TRACE("\n=============================================\n");
			}
			break;
		
		}
		default:   
             //syslog(LOG_WARNING, "%d signal unregister\n", signo);   
             break; 
    }
}


//��������addr server��У����
int main(int argc, char *argv[])
{
    //int	k;

	signal(SIGHUP, &signal_handler);   
    signal(SIGSEGV, &signal_handler);   
    signal(SIGQUIT, &signal_handler);   
    signal(SIGINT,  &signal_handler);   
    signal(SIGTERM, &signal_handler);   
    signal(SIGALRM, &signal_handler);   
    signal(SIGCHLD, &signal_handler);  
	signal(SIGPIPE, &signal_handler);  
	

	

	init_cypher_receiver();
	init_csa_dma(argv[1]);
	init_csa_crack();
	while(1){
		sleep(1);
	}
	
	

	return 0;
}
