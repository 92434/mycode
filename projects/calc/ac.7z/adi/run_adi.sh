sudo ./adi -F 50
