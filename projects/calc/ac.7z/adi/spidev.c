/*
 * SPI testing utility (using spidev driver)
 *
 * Copyright (c) 2007  MontaVista Software, Inc.
 * Copyright (c) 2007  Anton Vorontsov <avorontsov@ru.mvista.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 *
 * Cross-compile with cross-gcc -I/path/to/cross-kernel/include
 */

#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

#include "AD9125.h"
#include "AD9516.h"

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define	GPIO_PATH "/proc/gpio_test/"
#define GPIO_S0 "165"	//FMC_LPC_LA22_P
#define GPIO_S1 "160"	//FMC_LPC_LA19_P
#define GPIO_S2 "161"	//FMC_LPC_LA19_N
#define GPIO_ADF4350_LE "179" //load enable FMC_LPC_LA18_CC_P
#define GPIO_ADF4350_CE GPIO_S2 //chip enable FMC_LPC_LA19_N
#define GPIO_ADL5375_DSOP 	"168"	//FMC_LPC_CLK1_M2C_P
/*
157	R84.1	FMC_LPC_LA30_N(I2C_SCL0)
158	R83.1	FMC_LPC_LA30_P(I2C_SDA0)
159	R78.1	FMC_LPC_LA21_N(None)
160	R75.1	FMC_LPC_LA19_P(None)
161	R76.1	FMC_LPC_LA19_N(None)
162	R74.1	FMC_LPC_LA15_N(None)
163	R64.1	FMC_LPC_CLK0_M2C_N(None)
164	R62.1	FMC_LPC_PRSNT_M2C_B_LS(None)
165	R52.1	FMC_LPC_LA22_P(None)
166	R51.1	FMC_LPC_LA20_N(SPI_MISO)
167	R39.1	FMC_LPC_CLK1_M2C_N(None)
168	R38.1	FMC_LPC_CLK1_M2C_P(None)
169	R85.1	FMC_LPC_LA32_P(SPI_CS)
170	R60.1	FMC_LPC_LA33_P(None)
171	R33.1	FMC_LPC_LA26_N(None)
172	R31.1	FMC_LPC_LA23_N(SPI_MOSI)
173	R30.1	FMC_LPC_LA23_P(SPI_SCK)
174	R29.1	FMC_LPC_LA17_CC_N(None)
175	R28.1	FMC_LPC_LA17_CC_P(None)
176	R14.1	FMC_LPC_LA27_N(None)
177	R13.1	FMC_LPC_LA27_P(None)
178	R12.1	FMC_LPC_LA18_CC_N(None)
179	R11.1	FMC_LPC_LA18_CC_P(None)
*/

//"proc/gpio_test/178" muxout
static int handle_gpio_s0;
static int handle_gpio_s1;
static int handle_gpio_s2;
static int handle_gpio_ADF4350_LE,handle_gpio_ADF4350_CE;
static void pabort(const char *s)
{
	perror(s);
	abort();
}

static const char *device = "/dev/spidev1.0";
static uint8_t mode = 0;
static uint8_t bits = 8;
static uint32_t speed = 1000000;
static uint16_t delay = 0;

struct st_cmd
{
	uint8_t cmd;
	const char *cmd_str;
};

#define READ_REG(x) (x | 0x80)
#define WRITE_REG(x) (x)
typedef enum _read_write {
	spi_read = 0,
	spi_write,
} read_write_t;

static const struct st_cmd cmds[] =
{
	{0, "exit"},
	{1, "reset"},
	{2, "read device id 0"},
	{3, "read device id 1"},
	{4, "read reg"},
	{5, "write reg"},
	{6, "change reg"},
	{7, "read all reg"},
	{8, "chip initialize"},
};

void print_bin(int n)
{
    int l = sizeof(n)*8;//��λ����
    int i;
    if(i == 0)
    {
         printf("0");
         return;
     }
    for(i = l-1; i >= 0; i --)//��ȥ��λ0.
    {
        if(n&(1<<i)) break;
    }

    for(;i>=0; i --)
        printf("%d", (n&(1<<i)) != 0);
}


static int reg_op(int fd, unsigned char reg, unsigned char *pvalue, read_write_t read_write) {
	int ret = 0;
#define BUFFER_LEN 128
	uint8_t tx[BUFFER_LEN] = {0xff};
	uint8_t rx[BUFFER_LEN] = {0xff};
	struct spi_ioc_transfer tr[2] = {
		{
			.tx_buf = (unsigned long)tx,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = bits,
		},
		{
			.tx_buf = 0,
			.rx_buf = (unsigned long)rx,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = bits,
		}
	};
	struct spi_ioc_transfer *ptr_tx = tr, *ptr_rx = tr + 1;
	int msg_count = 0;

	switch(read_write) {
		case spi_write: {
					tx[ptr_tx->len] = WRITE_REG(reg);
					(ptr_tx->len)++;
					tx[ptr_tx->len] = *pvalue;
					(ptr_tx->len)++;
					msg_count = 1;
				}
				break;
		case spi_read: {
				       tx[ptr_tx->len] = READ_REG(reg);
				       (ptr_tx->len)++;
				       ptr_rx->len = ptr_tx->len;
				       msg_count = 2;
			       }
			       break;
		default:
			       pabort("unspport spi message");
			       break;
	}

	printf("%s", "send:");
	for (ret = 0; ret < ptr_tx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", tx[ret]);
	}

	puts("");

	ret = ioctl(fd, SPI_IOC_MESSAGE(msg_count), tr);
	if (ret < 1)
		pabort("can't send spi message");


	printf("%s", "receive:");
	for (ret = 0; ret < ptr_rx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", rx[ret]);
		*pvalue = rx[ret];
	}
	puts("");
	return ret;
}
static int reg_read_16bit(int fd, unsigned short reg, unsigned char *pvalue, int read_len) {
	int ret = 0;
#define BUFFER_LEN 128
	uint8_t tx[BUFFER_LEN] = {0xff};
	uint8_t rx[BUFFER_LEN] = {0xff};
	struct spi_ioc_transfer tr[2] = {
		{
			.tx_buf = (unsigned long)tx,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 16,
		},
		{
			.tx_buf = 0,
			.rx_buf = (unsigned long)rx,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 8,
		}
	};
	struct spi_ioc_transfer *ptr_tx = tr, *ptr_rx = tr + 1;
	int msg_count = 0;
	tx[0] = (reg&0xFF);
	tx[1] = (reg>>8)&0xFF;
	ptr_tx->len = 2;
	ptr_rx->len = read_len;
	msg_count = 2;

	/*printf("%s", "send:");
	for (ret = 0; ret < ptr_tx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", tx[ret]);
	}

	puts("");
	*/
	ret = ioctl(fd, SPI_IOC_MESSAGE(msg_count), tr);
	if (ret < 1)
		pabort("can't send spi message");


	//printf("%s", "receive:");
	for (ret = 0; ret < ptr_rx->len; ret++) {
		//if ((ret != 0) && (ret % 16 == 0))
			//puts("");
		//printf("%.2X ", rx[ret]);
		*pvalue = rx[ret];
	}
	//puts("");
	return ret;
}

static int reg_write_16bit(int fd, unsigned short reg, unsigned char *pvalue, int write_len) {
	int ret = 0;
#define BUFFER_LEN 128
	uint8_t cmd[2] = {0xff};
	uint8_t tx[BUFFER_LEN] = {0xff};
	struct spi_ioc_transfer tr[2] = {
		{
			.tx_buf = (unsigned long)cmd,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 16,
		},
		{
			.tx_buf = (unsigned long)tx,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 8,
		}
	};
	
	struct spi_ioc_transfer *ptr_cmd = tr, *ptr_tx = tr + 1;
	int msg_count = 0;
	cmd[0] = (reg&0xFF);
	cmd[1] = (reg>>8)&0xFF;
	ptr_cmd->len = 2;
	ptr_tx->len = write_len;
	memcpy(tx,pvalue,write_len);
	msg_count = 2;
	
	/*printf("%s", "send:");
	for (ret = 0; ret < ptr_tx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", tx[ret]);
	}

	puts("");*/

	ret = ioctl(fd, SPI_IOC_MESSAGE(msg_count), tr);
	if (ret < 1)
		pabort("can't send spi message");


	return ret;
}

static int write_multiByte_reg_op(int fd, unsigned char *pvalue,int len) {
	int ret = 0;
	#define BUFFER_LEN 128
	uint8_t tx[BUFFER_LEN] = {0xff};
	char zero='0',one='1';
	struct spi_ioc_transfer tr[2] = {
		{
			.tx_buf = (unsigned long)tx,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 32,
		},
		{
			.tx_buf = 0,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = 32,
		}
	};
	struct spi_ioc_transfer *ptr_tx = tr, *ptr_rx = tr + 1;
	int msg_count = 0;

	memcpy(tx,pvalue,len);
	ptr_tx->len=len;
	msg_count = 1;

	printf("%s", "send:");
	for (ret = 0; ret < ptr_tx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", tx[ret]);
	}

	puts("");
	write(handle_gpio_ADF4350_LE,&zero,1);
	ret = ioctl(fd, SPI_IOC_MESSAGE(msg_count), tr);
	if (ret < 1)
		pabort("can't send spi message");
	write(handle_gpio_ADF4350_LE,&one,1);
	write(handle_gpio_ADF4350_LE,&zero,1);
	return ret;
}

static int read_multiByte_reg_op(int fd, unsigned char reg,unsigned char *pvalue,int len) {
	int ret = 0;
	#define BUFFER_LEN 128
	uint8_t tx[BUFFER_LEN] = {0xff};
	uint8_t rx[BUFFER_LEN] = {0xff};
	struct spi_ioc_transfer tr[2] = {
		{
			.tx_buf = (unsigned long)tx,
			.rx_buf = 0,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = bits,
		},
		{
			.tx_buf = 0,
			.rx_buf = (unsigned long)rx,
			.len = 0,
			.delay_usecs = delay,
			.speed_hz = speed,
			.bits_per_word = bits,
		}
	};
	struct spi_ioc_transfer *ptr_tx = tr, *ptr_rx = tr + 1;
	int msg_count = 0;

	tx[ptr_tx->len] = READ_REG(reg);
	ptr_tx->len=1;
	
	ptr_rx->len=len;
	msg_count = 2;

	printf("%s", "send:");
	for (ret = 0; ret < ptr_tx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", tx[ret]);
	}

	puts("");
	
	ret = ioctl(fd, SPI_IOC_MESSAGE(msg_count), tr);
	if (ret < 1)
		pabort("can't send spi message");
	
	printf("%s", "receive:");
	for (ret = 0; ret < ptr_rx->len; ret++) {
		if ((ret != 0) && (ret % 16 == 0))
			puts("");
		printf("%.2X ", rx[ret]);
		pvalue[ret] = rx[ret];
	}
	puts("");
	return ret;
}
static int write_reg(int fd, unsigned char reg, unsigned char value) {
	int ret = 0;
	ret =reg_op(fd, reg, &value, spi_write);
	return ret;
}

static unsigned char read_reg(int fd, unsigned char reg) {
	int ret = 0;
	unsigned char value;
	ret =reg_op(fd, reg, &value, spi_read);
	return value;
}

static int read_and_write_reg(int fd, unsigned char reg, unsigned char mask, unsigned char value) {
	int ret = 0;
	unsigned char temp_value = read_reg(fd, reg);
	temp_value = temp_value & (~mask);
	value = value & mask;
	ret =write_reg(fd, reg, temp_value | value);
	return ret;
}

static unsigned char tty_get_char(void) {
	unsigned int c;

	while(scanf("%x", &c) != 1) {
		scanf("%*s"); 
		printf("input error!!! press [[enter]] retry!!!\n");
	}
	printf("get %x\n", c);

	return c;
}

void init_spi_cs(void){
	char gpio_pin_path[32]={0};
	char gpio_no[3][4]={GPIO_S0,GPIO_S1,GPIO_S2};
	int handle_gpio_export=open("/proc/gpio_test/export", O_RDWR);
	if(handle_gpio_export < 0){
		printf("open handle_gpio_export fail:%s\n",strerror(errno));
		return;
	}
	write(handle_gpio_export,gpio_no[0],3);
	write(handle_gpio_export,gpio_no[1],3);
	write(handle_gpio_export,gpio_no[2],3);

	snprintf(gpio_pin_path,32,"%s%s",GPIO_PATH,GPIO_S0);
	handle_gpio_s0= open(gpio_pin_path, O_RDWR);
	if(handle_gpio_s0 < 0){
		printf("open handle_gpio_s0 fail:%s\n",strerror(errno));
		return;
	}
	snprintf(gpio_pin_path,32,"%s%s",GPIO_PATH,GPIO_S1);
	handle_gpio_s1= open(gpio_pin_path, O_RDWR);
	if(handle_gpio_s1 < 0){
		printf("open handle_gpio_s1 fail:%s\n",strerror(errno));
		return;
	}
	snprintf(gpio_pin_path,32,"%s%s",GPIO_PATH,GPIO_S2);
	handle_gpio_s2= open(gpio_pin_path, O_RDWR);
	if(handle_gpio_s2 < 0){
		printf("open handle_gpio_s2 fail:%s\n",strerror(errno));
		return;
	}
}
void select_ad9125(void){
	char zero='0';
	write(handle_gpio_s0,&zero,1);
	write(handle_gpio_s1,&zero,1);
	write(handle_gpio_s2,&zero,1);
}
void select_ad9516(void){
	char one='1';
	char zero='0';
	write(handle_gpio_s0,&one,1);
	write(handle_gpio_s1,&zero,1);
	write(handle_gpio_s2,&zero,1);
}

void destroy_spi_cs(){
	if(handle_gpio_s0){
		close(handle_gpio_s0);
	}
	if(handle_gpio_s1){
		close(handle_gpio_s1);
	}
	if(handle_gpio_s2){
		close(handle_gpio_s2);
	}
}

void AD9516_WriteReg(int fd,unsigned short RegAddr, unsigned char *pData, unsigned short WrMode, unsigned char num)
{
	unsigned short tmp = 0;
	
	tmp = RegAddr | WrMode | AD9516_WRITE;
	reg_write_16bit(fd, tmp, pData,num);
	printf("write reg,addr:%0x,buf:%0x\n",RegAddr,pData[0]);
}
void AD9516_ReadReg(int fd,unsigned short RegAddr, unsigned char *pData, unsigned short RdMode, unsigned char num)
{
	unsigned short tmp = 0;
	
	tmp = AD9516_READ | RdMode | RegAddr;
	reg_read_16bit(fd, tmp, pData, num);
	printf("read reg,addr:%0x,buf:%0x\n",RegAddr,pData[0]);
}

void AD9516_UpdateRegister(int fd)
{
	unsigned short tmp1;
	unsigned char tmp2;
	
	tmp1 = AD9516_WRITE | ONE_BYTE |0x232;
	tmp2 = 0x01;
}
/*
Table 24. Settings When Using Internal VCO
Register									Function
0x010[1:0] = 00b					PLL normal operation (PLL on).
0x010 to 0x01E						PLL settings. Select and enable a reference
										input; set R, N (P, A, B), PFD polarity, and ICP,
										according to the intended loop configuration.
0x018[0] = 0b,						Reset VCO calibration. This is not required
0x232[0] = 1b							the first time after power-up, but it must
										be performed subsequently. 
0x1E0[2:0] 							Set VCO divider to divide-by-2, divide-by-3,
										divide-by-4, divide-by-5, and divide-by-6.
0x1E1[0] = 0b 						Use the VCO divider as source for the
										distribution section. 
0x1E1[1] = 1b 						Select VCO as the source.
0x018[0] = 1b,						Initiate VCO calibration.
0x232[0] = 1b
*/
//122.88MHz		VCO:2457.600000,A:32,B:7295,P_value[5]:32,R:2375 
static int do_cmd_AD9516(int fd){
	unsigned char cdata = 0;	
	unsigned char test_buf[10];
	int count=0;
	unsigned short read_reg_id=0;
	
	cdata = 0x3C;
	AD9516_WriteReg(fd,0x0,&cdata,ONE_BYTE,1);//soft reset
	cdata = 0x18|SERIAL_SDO_ACTIVE;
	AD9516_WriteReg(fd,0x0,&cdata,ONE_BYTE,1);//clear reset

	/*cdata=0xA8;
	AD9516_WriteReg(fd,0x17,&cdata,ONE_BYTE,1);//status pin
	cdata=0x07;
	AD9516_WriteReg(fd,0x1B,&cdata,ONE_BYTE,1);//REFMON pin
	*/
	
	#if 1 
	//PLL config
	cdata=0x7C;
	AD9516_WriteReg(fd,0x10,&cdata,ONE_BYTE,1);//PFD_CHARGE_PUMP
	cdata=0x02;
	AD9516_WriteReg(fd,0x1C,&cdata,ONE_BYTE,1);//select ref1 power on

	


	cdata=0x06;
	AD9516_WriteReg(fd,0x18,&cdata,ONE_BYTE,1);//Reset VCO calibration
	cdata=0x01;
	AD9516_WriteReg(fd,0x232,&cdata,ONE_BYTE,1);
/*
	cdata=0x0F;
	AD9516_WriteReg(fd,0x11,&cdata,ONE_BYTE,1);
	//cdata=0x09;
	//AD9516_WriteReg(fd,0x12,&cdata,ONE_BYTE,1);
	cdata=0x28;
	AD9516_WriteReg(fd,0x13,&cdata,ONE_BYTE,1);
	cdata=0x2e;
	AD9516_WriteReg(fd,0x14,&cdata,ONE_BYTE,1);
	//cdata=0x1C;
	//AD9516_WriteReg(fd,0x15,&cdata,ONE_BYTE,1);
	cdata=0x16;
	AD9516_WriteReg(fd,0x16,&cdata,ONE_BYTE,1);
	cdata=0x07;
	AD9516_WriteReg(fd,0x18,&cdata,ONE_BYTE,1);
	cdata=0x02;
	AD9516_WriteReg(fd,0x1c,&cdata,ONE_BYTE,1);
*/
	cdata=0x5a;
	AD9516_WriteReg(fd,0x142,&cdata,ONE_BYTE,1);
	cdata=0x10;
	AD9516_WriteReg(fd,0x193,&cdata,ONE_BYTE,1);
	cdata=0x10;
	AD9516_WriteReg(fd,0x199,&cdata,ONE_BYTE,1);
	cdata=0x10;
	AD9516_WriteReg(fd,0x19E,&cdata,ONE_BYTE,1);
	cdata=0x00;
	AD9516_WriteReg(fd,0x1A0,&cdata,ONE_BYTE,1);
	
	//VCO Config
	cdata=0x00;
	AD9516_WriteReg(fd,0x1E0,&cdata,ONE_BYTE,1);//VCO divider 2
	cdata=0x02;
	AD9516_WriteReg(fd,0x1E1,&cdata,ONE_BYTE,1);//Select VCO as source CLK
	cdata=0x01;
	AD9516_WriteReg(fd,0x232,&cdata,ONE_BYTE,1);//updata all Reg

	//VCO calibraion
	
	cdata=0x07;
	AD9516_WriteReg(fd,0x18,&cdata,ONE_BYTE,1);//initial
	cdata=0x01;
	AD9516_WriteReg(fd,0x232,&cdata,ONE_BYTE,1);
	#endif

	
	while(1){
		printf("===========================(%3d)\n",count++);
		//AD9516_UpdateRegister(fd);
		AD9516_ReadReg(fd,PART_ID,test_buf,ONE_BYTE,1);
		printf("PART_ID:%x\n",test_buf[0]);
		AD9516_ReadReg(fd,0x1F,test_buf,ONE_BYTE,1);
		printf("Frequency monitor(0x1F) status:%x\n",test_buf[0]);
		sleep(1);
		break;
	}
	return 0;
}

static int do_cmd(int fd, int c)
{
#define BUFFER_LEN 128

	int ret = 0;

	printf("c:%d\n", c);
	if(c >= ARRAY_SIZE(cmds)) {
		return;
	}

	switch(c) {
		case 1:
			write_reg(fd, 0x00, 0);
			break;
		case 2:
			{
				unsigned char value;
				value = read_reg(fd, 0x00);
			}
			break;
		case 3:
			{
				unsigned char value;
				value = read_reg(fd, 0x01);
			}
			break;
		case 4:
			{
				unsigned char reg;
				unsigned char value;

				printf("input reg addr:");
				reg = tty_get_char();
				value = read_reg(fd, reg);
			}
			break;
		case 5:
			{
				unsigned char reg;
				unsigned char value;

				printf("input reg addr:");
				reg = tty_get_char();
				printf("input value:");
				value = tty_get_char();
				write_reg(fd, reg, value);
			}
			break;
		case 6:
			{
				unsigned char reg;
				unsigned char mask;
				unsigned char value;

				printf("input reg addr:");
				reg = tty_get_char();
				printf("input value mask:");
				mask = tty_get_char();
				printf("input value:");
				value = tty_get_char();
				read_and_write_reg(fd, reg, mask, value);
			}
			break;
		case 7:
			{
				unsigned char value;
				unsigned char reg = 0x00;
				for(reg = 0; reg < 0x1e; reg++) {
					printf("query reg:%02x\n", reg);
					value = read_reg(fd, reg);
					puts("");
				}
			}
			break;
		case 8: 
			{
				struct reg_default {
					unsigned int reg;
					unsigned int def;
				};

				static const struct reg_default wm8804_reg_defaults[] = {
					{ 3,  0x21 },     /* R3  - PLL1 */
					{ 4,  0xFD },     /* R4  - PLL2 */
					{ 5,  0x36 },     /* R5  - PLL3 */
					{ 6,  0x07 },     /* R6  - PLL4 */
					{ 7,  0x16 },     /* R7  - PLL5 */
					{ 8,  0x18 },     /* R8  - PLL6 */
					{ 9,  0xFF },     /* R9  - SPDMODE */
					{ 10, 0x00 },     /* R10 - INTMASK */
					{ 18, 0x00 },     /* R18 - SPDTX1 */
					{ 19, 0x00 },     /* R19 - SPDTX2 */
					{ 20, 0x00 },     /* R20 - SPDTX3 */
					{ 21, 0x71 },     /* R21 - SPDTX4 */
					{ 22, 0x0B },     /* R22 - SPDTX5 */
					{ 23, 0x70 },     /* R23 - GPO0 */
					{ 24, 0x57 },     /* R24 - GPO1 */
					{ 26, 0x42 },     /* R26 - GPO2 */
					{ 27, 0x06 },     /* R27 - AIFTX */
					{ 28, 0x06 },     /* R28 - AIFRX */
					{ 29, 0x80 },     /* R29 - SPDRX1 */
					{ 30, 0x07 },     /* R30 - PWRDN */
				};
				
				int count = sizeof(wm8804_reg_defaults) / sizeof(struct reg_default);
				int i;
				for(i = 0; i < count; i++) {
					write_reg(fd, wm8804_reg_defaults[i].reg, wm8804_reg_defaults[i].def);	
				}

				write_reg(fd, 0x15, 0x38);//txsrc is spdif
				write_reg(fd, 0x1c, 0x46);//master output
				//write_reg(fd, 0x1c, 0x06);//slave input
				write_reg(fd, 0x1e, 0x00);//spdif enable | pll enable
				write_reg(fd, 0x1b, 0x0a);//aiftx 24bit, i2s
				
				//write_reg(fd, 0x1e, 0x00);//spdif enable | pll enable
				//write_reg(fd, 0x15, 0x38);//txsrc is spdif
				//write_reg(fd, 0x1c, 0x46);//master output
			}
			break;
		default:
			pabort("unspport spi message");
			break;
	}

	return ret;
}

static int do_cmd_AD9125_test(int fd){
	int i,ret=0;
	unsigned char value=0; 
	ret=write_reg(fd,(WRITE | COMM),RESET);
	sleep(1);
	ret=write_reg(fd,(WRITE | COMM),0);
	while(1){
		value = read_reg(fd, (READ | CHIP_ID));
		printf("[do_cmd_AD9125_test read]value:%0x\n",value);
		sleep(1);
	}
	return 0;
}

static int do_cmd_AD9125(int fd)
{
	int i,ret=0;
	unsigned char value=0;
	#if 1
	ret=write_reg(fd,(WRITE | COMM),RESET);
	ret=write_reg(fd,(WRITE | COMM),0);
	
	ret=write_reg(fd,(WRITE | PLL_CONTROL_3),0xDF);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_4),0xC9);
	//ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0xC0|0x26);//PLL config, 
	//ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0xA0);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0x00);
	/*
	ret=write_reg(fd,(WRITE | PLL_CONTROL_3),0xD1);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_4),0xD9);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0xCF);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0xA0);

	
	value = read_reg(fd, (READ | PLL_STATUS_1));
	printf("PLL_STATUS_1:%02x\n",value);
	value = read_reg(fd, (READ | EVENT_FLAG_1));
	printf("EVENT_FLAG_1:%02x\n",value);

	ret=write_reg(fd,(WRITE | SYNC_CONTROL_1),0x48);
	ret=write_reg(fd,(WRITE | 0X17),0x04);
	ret=write_reg(fd,(WRITE | 0X18),0x02);
	ret=write_reg(fd,(WRITE | 0X18),0x00);
	value = read_reg(fd, (READ | FIFO_STATUS_1));
	printf("FIFO_STATUS_1:%02x\n",value);
	value = read_reg(fd, (READ | FIFO_STATUS_2));
	printf("FIFO_STATUS_2:%02x\n",value);


	ret=write_reg(fd,(WRITE | DATAPATH_CONTROL),0x84);
	ret=write_reg(fd,(WRITE | 0X1C),0x04);
	ret=write_reg(fd,(WRITE | 0X1D),0x24);
	ret=write_reg(fd,(WRITE | 0x1E),0x01);
	
	ret=write_reg(fd,(WRITE | 0x30),0x55);
	ret=write_reg(fd,(WRITE | 0x31),0x55);
	ret=write_reg(fd,(WRITE | 0x32),0xD5);
	ret=write_reg(fd,(WRITE | 0x33),0x11);
	ret=write_reg(fd,(WRITE | 0x36),0x01);
	ret=write_reg(fd,(WRITE | 0x36),0x00);
	*/
	ret=write_reg(fd,(WRITE | SYNC_CONTROL_1),0x48);//0xC0  //sync config ,close sync
	ret=write_reg(fd,(WRITE | FIFO_CONTROL),0x04);
	ret=write_reg(fd,(WRITE | FIFO_STATUS_1),0x02);
	for(i=0;i<100;i++){
		value = read_reg(fd, (READ | FIFO_STATUS_1));
		if((value&0x04)>>2==1){
			printf("FIFO soft align acknowledge\n");
			break;
		}
		usleep(50000);
	}
	if(i>=100){
		printf("FIFO soft align fail\n");
	}
	ret=write_reg(fd,(WRITE | FIFO_STATUS_1),0x00);
	for(i=0;i<100;i++){
		value = read_reg(fd, (READ | FIFO_STATUS_1));
		if((value&0x04)>>2==0){
			printf("FIFO soft align clear\n");
			break;
		}
		usleep(50000);
	}
	if(i>=100){
		printf("FIFO soft align not clear\n");
	}
	//int HB1_step=0;
	
	#if 1 //no shift
	ret=write_reg(fd,(WRITE | DATAPATH_CONTROL),0x84);
	ret=write_reg(fd,(WRITE | HB1_CONTROL_1),0x00);
	ret=write_reg(fd,(WRITE | HB2_CONTROL_2),0x00);
	ret=write_reg(fd,(WRITE | HB3_CONTROL_3),0x01);
	#else	//shift fDATA/2
	ret=write_reg(fd,(WRITE | DATAPATH_CONTROL),0x64);
	ret=write_reg(fd,(WRITE | HB1_CONTROL_1),0x02);
	ret=write_reg(fd,(WRITE | HB2_CONTROL_2),0x12);
	ret=write_reg(fd,(WRITE | HB3_CONTROL_3),0x01);
	#endif
	//ret=write_reg(fd,(WRITE | 0x43),0x20);
	//ret=write_reg(fd,(WRITE | 0x47),0x20);
	
	/*ret=write_reg(fd,(WRITE | 0x30),0x55);//0xE0
	ret=write_reg(fd,(WRITE | 0x31),0x55);
	ret=write_reg(fd,(WRITE | 0x32),0xD5);
	ret=write_reg(fd,(WRITE | 0x33),0x11);
	ret=write_reg(fd,(WRITE | 0x36),0x01);
	ret=write_reg(fd,(WRITE | 0x36),0x00);
	*/
	while(1){
		value = read_reg(fd, (READ | EVENT_FLAG_1));
		printf("EVENT_FLAG_1:%02x\n",value);
		value = read_reg(fd, (READ | EVENT_FLAG_2));
		printf("EVENT_FLAG_2:%02x\n",value);
		value = read_reg(fd, (READ | SYNC_STATUS_1));
		printf("SYNC_STATUS_1:%02x\n",value);
		value = read_reg(fd, (READ | SYNC_STATUS_2));
		printf("SYNC_STATUS_2:%02x\n",value);
		value = read_reg(fd, (READ | FIFO_STATUS_1));
		printf("FIFO_STATUS_1:%02x\n",value);
		value = read_reg(fd, (READ | FIFO_STATUS_2));
		printf("FIFO_STATUS_2:%d (",value);
		print_bin(value);
		printf(")\n");
		sleep(1);

		/*HB1_step+=2;
		if(HB1_step>6)
			HB1_step=0;
		ret=write_reg(fd,(WRITE | HB1_CONTROL_1),HB1_step);*/
	}
	
	#else
	int vco_band_select=0;
	ret=write_reg(fd,(WRITE | COMM),RESET);
	sleep(1);
	ret=write_reg(fd,(WRITE | COMM),0);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_3),0xD1);
	ret=write_reg(fd,(WRITE | PLL_CONTROL_4),0xD8);
	
	//find a vco_band in order to get a best vco working voltage
	for(vco_band_select=0;vco_band_select<64;vco_band_select++){
		int vco_voltage=0;
		ret=write_reg(fd,(WRITE | PLL_CONTROL_1),0xC0|vco_band_select);
		usleep(50000);
		value = read_reg(fd, (READ | 0x0E));
		vco_voltage=value&0x0F;
		if(value>>7==1&&(vco_voltage>=7&&vco_voltage<=8)){
			printf("PLL locked(value:%02x). vco_band_select:%d,vco_voltage:0x%x\n",value,vco_band_select,vco_voltage);
			break;
		}
	}
	#endif
	
	return ret;
}

static int init_ADF4350(){
	char one='1';
	char gpio_pin_path[32]={0};
	char gpio_no[3][4]={GPIO_ADF4350_LE,GPIO_ADF4350_CE};
	int handle_gpio_export=open("/proc/gpio_test/export", O_RDWR);
	if(handle_gpio_export < 0){
		printf("open handle_gpio_export fail:%s\n",strerror(errno));
		return -1;
	}
	write(handle_gpio_export,gpio_no[0],3);
	write(handle_gpio_export,gpio_no[1],3);

	snprintf(gpio_pin_path,32,"%s%s",GPIO_PATH,GPIO_ADF4350_LE);
	printf("init_ADF4350,le path:%s\n",gpio_pin_path);
	handle_gpio_ADF4350_LE= open(gpio_pin_path, O_RDWR);
	if(handle_gpio_ADF4350_LE < 0){
		printf("open handle_gpio_ADF4350_LE fail:%s\n",strerror(errno));
		return -1;
	}
	snprintf(gpio_pin_path,32,"%s%s",GPIO_PATH,GPIO_ADF4350_CE);
	handle_gpio_ADF4350_CE= open(gpio_pin_path, O_RDWR);
	if(handle_gpio_ADF4350_CE < 0){
		printf("open handle_gpio_ADF4350_CE fail:%s\n",strerror(errno));
		return -1;
	}
	write(handle_gpio_ADF4350_CE,&one,1);
	close(handle_gpio_export);
	return 0;
}
static int close_ADF4350(){
	if(handle_gpio_ADF4350_LE >= 0){
		close(handle_gpio_ADF4350_LE);
		return 0;
	}
	if(handle_gpio_ADF4350_CE >= 0){
		close(handle_gpio_ADF4350_CE);
		return 0;
	}
	return -1;
}

static void test_ADF4350_led(int fd){
	int ret=0;
	unsigned	char	buf[4] = {0,0,0,0};
	int i;
	for(i=0;i<3;i++){
		//R5
		buf[3] = 0x00;
		buf[2] = 0xD8;
		buf[1] = 0x00;				//write communication register 0x00580005 to control the progress 
	 	buf[0] = 0x05;				//to write Register 5 to set digital lock detector
		ret=write_multiByte_reg_op(fd, buf, 4);

		sleep(1);
		//R5
		buf[3] = 0x00;
		buf[2] = 0x98;
		buf[1] = 0x00;				//write communication register 0x00580005 to control the progress 
	 	buf[0] = 0x05;				//to write Register 5 to set digital lock detector
		ret=write_multiByte_reg_op(fd, buf, 4);
		sleep(1);
	}
}
static int do_cmd_ADF4350(int fd)
{
	int ret=0;
	unsigned	char	buf[4] = {0,0,0,0};
	#if 1
	//R5
	buf[3] = 0x00;
	buf[2] = 0x58;
	buf[1] = 0x00;				//write communication register 0x00580005 to control the progress 
 	buf[0] = 0x05;				//to write Register 5 to set digital lock detector
	ret=write_multiByte_reg_op(fd, buf, 4);

	//R4
	buf[3] = 0x00;
	buf[2] = 0xba;				//(DB23=1)The signal is taken from the VCO directly;(DB22-20:4H)the RF divider is 16;(DB19-12:50H)R is 80
	buf[1] = 0x00;				//(DB11=0)VCO powerd up;
 	buf[0] = 0x3c;				//(DB5=1)RF output is enabled;(DB4-3=3H)Output power level is 5
	ret=write_multiByte_reg_op(fd, buf, 4);

	//R3
	buf[3] = 0x00;
	buf[2] = 0x00;
	buf[1] = 0x04;				//(DB14-3:96H)clock divider value is 150.
 	buf[0] = 0xB3;
	ret=write_multiByte_reg_op(fd, buf, 4);

	//R2
	buf[3] = 0x14;
	buf[2] = 0x00;				//(DB6=1)set PD polarity is positive;(DB7=1)LDP is 6nS;
	buf[1] = 0x5f;				//(DB8=0)enable fractional-N digital lock detect;
 	buf[0] = 0x42;				//(DB12-9:7H)set Icp 2.50 mA;
								//(DB23-14:1H)R counter is 1
	ret=write_multiByte_reg_op(fd, buf, 4);

	//R1
	buf[3] = 0x08;
	buf[2] = 0x00;
	buf[1] = 0x80;			   //(DB14-3:6H)MOD counter is 6;
 	buf[0] = 0x09;			   //(DB26-15:6H)PHASE word is 1,neither the phase resync 
							   //nor the spurious optimization functions are being used
							   //(DB27=1)prescaler value is 8/9
	ret=write_multiByte_reg_op(fd, buf, 4);

	//R0
	buf[3] = 0x00;
	buf[2] = 0x3c;
	buf[1] = 0x00;
 	buf[0] = 0x00;				//(DB14-3:0H)FRAC value is 0;
								//(DB30-15:140H)INT value is 320;
	ret=write_multiByte_reg_op(fd, buf, 4);
	#else
	//R5
	buf[3] = 0x00;
	buf[2] = 0xD8;
	buf[1] = 0x00;				//write communication register 0x00580005 to control the progress 
 	buf[0] = 0x05;				//to write Register 5 to set digital lock detector
	ret=write_multiByte_reg_op(fd, buf, 4);
	

	sleep(2);
	//R5
	buf[3] = 0x00;
	buf[2] = 0x98;
	buf[1] = 0x00;				//write communication register 0x00580005 to control the progress 
 	buf[0] = 0x05;				//to write Register 5 to set digital lock detector
	ret=write_multiByte_reg_op(fd, buf, 4);
	#endif
	return ret;
}


static void print_usage(const char *prog)
{
	printf("Usage: %s [-DsbdlHOLC3]\n", prog);
	puts("  -D --device   device to use (default /dev/spidev1.1)\n"
			"  -s --speed    max speed (Hz)\n"
			"  -d --delay    delay (usec)\n"
			"  -b --bpw      bits per word \n"
			"  -l --loop     loopback\n"
			"  -H --cpha     clock phase\n"
			"  -O --cpol     clock polarity\n"
			"  -L --lsb      least significant bit first\n"
			"  -C --cs-high  chip select active high\n"
			"  -3 --3wire    SI/SO signals shared\n");
	exit(1);
}

static void parse_opts(int argc, char *argv[])
{
	while (1) {
		static const struct option lopts[] = {
			{ "device",  1, 0, 'D' },
			{ "speed",   1, 0, 's' },
			{ "delay",   1, 0, 'd' },
			{ "bpw",     1, 0, 'b' },
			{ "loop",    0, 0, 'l' },
			{ "cpha",    0, 0, 'H' },
			{ "cpol",    0, 0, 'O' },
			{ "lsb",     0, 0, 'L' },
			{ "cs-high", 0, 0, 'C' },
			{ "3wire",   0, 0, '3' },
			{ "no-cs",   0, 0, 'N' },
			{ "ready",   0, 0, 'R' },
			{ NULL, 0, 0, 0 },
		};
		int c;

		c = getopt_long(argc, argv, "D:s:d:b:lHOLC3NR", lopts, NULL);

		if (c == -1)
			break;

		switch (c) {
			case 'D':
				device = optarg;
				break;
			case 's':
				speed = atoi(optarg);
				break;
			case 'd':
				delay = atoi(optarg);
				break;
			case 'b':
				bits = atoi(optarg);
				break;
			case 'l':
				mode |= SPI_LOOP;
				break;
			case 'H':
				mode |= SPI_CPHA;
				break;
			case 'O':
				mode |= SPI_CPOL;
				break;
			case 'L':
				mode |= SPI_LSB_FIRST;
				break;
			case 'C':
				mode |= SPI_CS_HIGH;
				break;
			case '3':
				mode |= SPI_3WIRE;
				break;
			case 'N':
				mode |= SPI_NO_CS;
				break;
			case 'R':
				mode |= SPI_READY;
				break;
			default:
				print_usage(argv[0]);
				break;
		}
	}
}

int main(int argc, char *argv[])
{
	int ret = 0;
	int fd;
	int i;
	int c;
	int loop_times=0;
	parse_opts(argc, argv);

		
	fd = open(device, O_RDWR);
	if (fd < 0)
		pabort("can't open device");
	init_spi_cs();
	
	/*
	 * spi mode
	 */
	 printf("mode:%x\n",mode);
	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
		pabort("can't set spi mode");

	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
		pabort("can't get spi mode");

	/*
	 * bits per word
	 */
	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't set bits per word");

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't get bits per word");

	/*
	 * max speed hz
	 */
	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't set max speed hz");

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't get max speed hz");

	printf("spi mode: %d\n", mode);
	printf("bits per word: %d\n", bits);
	printf("max speed: %d Hz (%d KHz)\n", speed, speed/1000);

	
	#if 1//AD9516
	select_ad9516();
	do_cmd_AD9516(fd);
	return 0;
	#endif
	
	#if 1//ADF4350
	init_ADF4350();
	//test_ADF4350_led(fd);
	do_cmd_ADF4350(fd);
	#endif
	sleep(10);
	#if 1//AD9125
	select_ad9125();
	do_cmd_AD9125(fd);
//	do_cmd_AD9125_test(fd);
	#endif
	while(0)
	{
		/*printf("\n\n\n========================================\n");
		for(i = 0; i < ARRAY_SIZE(cmds); i++)
		{
			printf("%d. %s \n", i, cmds[i].cmd_str);
		}
		printf("========================================\n");
		printf(">>");
		if(scanf("%d", &c) != 1) {
			scanf("%*s");
			continue;
		}
		if(c == 0)
			break;
		else
		*/
		printf("\n\n\n========================================\n");
		do_cmd_ADF4350(fd);
		sleep(200);
		//usleep(2000000);
		loop_times++;
		if(loop_times>100000)
			break;
		/*
		set_ad9125_cs(1);
		printf("set_ad9125_cs 1\n");
		sleep(5);
		set_ad9125_cs(0);
		printf("set_ad9125_cs 0\n");
		sleep(5);
		*/
	}

	close(fd);
	close_ADF4350();
	destroy_spi_cs();
	return ret;
}
